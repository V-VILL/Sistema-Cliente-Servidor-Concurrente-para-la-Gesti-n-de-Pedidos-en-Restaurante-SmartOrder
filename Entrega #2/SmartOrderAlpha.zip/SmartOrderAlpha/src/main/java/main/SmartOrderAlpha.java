package main;

import network.Server;
import view.LoginVentana;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class SmartOrderAlpha {

    public static void main(String[] args) {
        // 1. Aplicar la apariencia visual del sistema operativo (Look and Feel)
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // 2. Levantar el Servidor Socket en un hilo secundario (en segundo plano)
        Thread hiloServidor = new Thread(() -> {
            Server servidor = new Server();
            servidor.iniciarServidor();
        });
        hiloServidor.setDaemon(true); // Permite que el hilo muera al cerrar la aplicación
        hiloServidor.start();

        System.out.println("[SISTEMA] Servidor central POS iniciado. Abriendo interfaz gráfica...");

        // 3. Lanzar la ventana de Login en el hilo de eventos de Swing (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginVentana login = new LoginVentana();
            login.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
            login.setVisible(true);
        });
    }
}
