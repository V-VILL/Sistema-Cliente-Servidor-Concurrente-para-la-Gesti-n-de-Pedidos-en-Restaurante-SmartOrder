package services;

import dao.AuditoriaDAO;
import dao.SesionUsuarioDAO;
import dao.UsuarioDAO;
import model.Usuario;

public class AuthServiceImpl implements IAuthService {
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final SesionUsuarioDAO sesionDAO = new SesionUsuarioDAO();
    private final AuditoriaDAO auditoriaDAO = new AuditoriaDAO();

    @Override
    public Usuario login(String email, String password) {
        Usuario usuario = usuarioDAO.validarLogin(email, password);
        if (usuario != null) {
            // Registrar inicio de sesión en BD
            sesionDAO.registrarInicioSesion(usuario.getIdUsuario());
            
            // Auditoría
            auditoriaDAO.registrarLog(usuario.getIdUsuario(), null, "LOGIN", "Inicio de sesión exitoso.");
        }
        return usuario;
    }

    @Override
    public boolean logout(Usuario usuario) {
        if (usuario == null) return false;
        
        boolean cerrado = sesionDAO.cerrarSesion(usuario.getIdUsuario());
        if (cerrado) {
            auditoriaDAO.registrarLog(usuario.getIdUsuario(), null, "LOGOUT", "Cierre de sesión del usuario.");
        }
        return cerrado;
    }
}
