package services;

import model.Pedido;
import java.util.List;

public interface IEstacionService {
    List<Pedido> obtenerPedidosPorEstacion(int idEstacion);
    boolean actualizarEstadoEnCocina(int idPedido, int nuevoEstado);
}
