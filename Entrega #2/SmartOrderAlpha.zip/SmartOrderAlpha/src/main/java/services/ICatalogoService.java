package services;

import model.Categoria;
import model.Mesa;
import model.Producto;
import java.util.List;

public interface ICatalogoService {
    List<Producto> obtenerMenuProductos();
    List<Mesa> obtenerMesas();
    List<Categoria> obtenerCategorias();
}

