package services;

import model.DetallePedido;
import model.Pedido;
import java.util.List;

public interface IPedidoService {
    boolean crearPedido(Pedido pedido, List<DetallePedido> detalles);
    boolean cambiarEstado(int idPedido, int nuevoEstado);
}
