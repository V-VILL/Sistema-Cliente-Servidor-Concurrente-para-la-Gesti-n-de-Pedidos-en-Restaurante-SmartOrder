package services;

import dao.CategoriaDAO;
import dao.MesaDAO;
import dao.ProductoDAO;
import model.Categoria;
import model.Mesa;
import model.Producto;
import java.util.List;

public class CatalogoServiceImpl implements ICatalogoService {
    private final ProductoDAO productoDAO = new ProductoDAO();
    private final MesaDAO mesaDAO = new MesaDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    public List<Producto> obtenerMenuProductos() {
        return productoDAO.obtenerProductosDisponibles();
    }

    @Override
    public List<Mesa> obtenerMesas() {
        return mesaDAO.obtenerMesas();
    }

    @Override
    public List<Categoria> obtenerCategorias() {
        return categoriaDAO.obtenerCategorias();
    }
}
