package services;

import model.Usuario;

public interface IAuthService {
    Usuario login(String email, String password);
    boolean logout(Usuario usuario);
}
