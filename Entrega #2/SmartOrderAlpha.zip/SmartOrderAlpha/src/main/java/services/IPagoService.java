package services;

public interface IPagoService {
    boolean procesarPago(int idPedido, String metodoPago, double monto, Integer idMesa);
}