package services;

import dao.AuditoriaDAO;
import dao.MesaDAO;
import dao.PagoDAO;
import dao.PedidoDAO;

public class PagoServiceImpl implements IPagoService {
    private final PagoDAO pagoDAO = new PagoDAO();
    private final MesaDAO mesaDAO = new MesaDAO();
    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final AuditoriaDAO auditoriaDAO = new AuditoriaDAO();

    @Override
    public boolean procesarPago(int idPedido, String metodoPago, double monto, Integer idMesa) {
        // 1. Registrar el pago en la base de datos
        boolean pagoExitoso = pagoDAO.registrarPago(idPedido, metodoPago, monto);

        if (pagoExitoso) {
            // 2. Cambiar estado del pedido a Entregado/Finalizado (Ej: Estado 4)
            pedidoDAO.cambiarEstadoPedido(idPedido, 4);

            // 3. Si el pedido era de mesa, liberar la mesa (cambiar a 'LIBRE')
            if (idMesa != null) {
                mesaDAO.actualizarEstadoMesa(idMesa, "LIBRE");
            }

            // 4. Registrar en auditoría
            auditoriaDAO.registrarLog(1, idPedido, "PAGO_PROCESADO", "Pago de $" + monto + " registrado vía " + metodoPago);
            return true;
        }
        return false;
    }
}
