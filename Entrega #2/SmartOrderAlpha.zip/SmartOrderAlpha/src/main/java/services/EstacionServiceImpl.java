package services;

import dao.PedidoDAO;
import model.Pedido;
import java.util.List;
import services.IEstacionService;

public class EstacionServiceImpl implements IEstacionService {
    private final PedidoDAO pedidoDAO = new PedidoDAO();

    @Override
    public List<Pedido> obtenerPedidosPorEstacion(int idEstacion) {
        // Aquí puedes consultar los pedidos filtrados por la estación de cocina
        // (puedes apoyarte en la tabla pedido_estacion a través de un DAO específico si lo requiere tu diagrama)
        return null; 
    }

    @Override
    public boolean actualizarEstadoEnCocina(int idPedido, int nuevoEstado) {
        return pedidoDAO.cambiarEstadoPedido(idPedido, nuevoEstado);
    }
}
