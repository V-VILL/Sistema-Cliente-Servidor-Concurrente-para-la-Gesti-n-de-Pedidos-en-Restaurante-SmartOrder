package services;

import concurrency.GestorPedidosConcurrente;
import dao.AuditoriaDAO;
import dao.MesaDAO;
import dao.PedidoDAO;
import model.DetallePedido;
import model.Pedido;
import java.util.List;

public class PedidoServiceImpl implements IPedidoService {
    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final MesaDAO mesaDAO = new MesaDAO();
    private final AuditoriaDAO auditoriaDAO = new AuditoriaDAO();

    @Override
    public boolean crearPedido(Pedido pedido, List<DetallePedido> detalles) {
        // 1. Guardar en Base de Datos con transacción atómica
        boolean exitoBD = pedidoDAO.registrarPedidoCompleto(pedido, detalles);

        if (exitoBD) {
            // 2. Si es para mesa, cambiar estado de la mesa a OCUPADA
            if (pedido.getIdMesa() != null) {
                mesaDAO.actualizarEstadoMesa(pedido.getIdMesa(), "OCUPADA");
            }

            // 3. Agregar a la estructura concurrente en memoria para la cola de cocina
            GestorPedidosConcurrente.agregarPedidoActivo(pedido);

            // 4. Auditoría
            auditoriaDAO.registrarLog(
                pedido.getIdUsuario(),
                pedido.getIdPedido(),
                "CREAR_PEDIDO",
                "Pedido #" + pedido.getIdPedido() + " registrado correctamente."
            );
            return true;
        }
        return false;
    }

    @Override
    public boolean cambiarEstado(int idPedido, int nuevoEstado) {
        return pedidoDAO.cambiarEstadoPedido(idPedido, nuevoEstado);
    }
}