package controller;

import dao.AuditoriaDAO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.List;

public class AuditoriaController {
    private final AuditoriaDAO auditoriaDAO;

    public AuditoriaController() {
        this.auditoriaDAO = new AuditoriaDAO();
    }

    public List<AuditoriaDAO.RegistroAuditoria> obtenerHistorialAuditoria(JFrame ventanaActual) {
        try {
            return auditoriaDAO.obtenerRegistrosAuditoria();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al cargar la bitácora de auditoría.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
}