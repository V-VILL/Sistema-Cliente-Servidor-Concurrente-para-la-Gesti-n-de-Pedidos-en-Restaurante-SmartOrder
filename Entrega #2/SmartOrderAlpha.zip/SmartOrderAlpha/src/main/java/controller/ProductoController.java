package controller;

import dao.ProductoDAO;
import model.Producto;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.List;

public class ProductoController {
    private final ProductoDAO productoDAO;

    public ProductoController() {
        this.productoDAO = new ProductoDAO();
    }

    public List<Producto> obtenerTodosLosProductos(JFrame ventanaActual) {
        try {
            return productoDAO.obtenerTodosLosProductos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al cargar el catálogo de productos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    // Método requerido por PedidoVentana para cargar los productos disponibles en la venta
    public List<Producto> obtenerCatalogoProductos(JFrame ventanaActual) {
        try {
            return productoDAO.obtenerProductosDisponibles();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al cargar el catálogo de productos disponibles.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public boolean guardarProducto(Producto producto, JFrame ventanaActual) {
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
            JOptionPane.showMessageDialog(ventanaActual, "El nombre del producto no puede estar vacío.", "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        boolean exito = productoDAO.registrarProducto(producto);
        if (exito) {
            JOptionPane.showMessageDialog(ventanaActual, "Producto agregado exitosamente al menú.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, "No se pudo registrar el producto en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return exito;
    }

    public boolean actualizarProducto(Producto producto, JFrame ventanaActual) {
        boolean exito = productoDAO.actualizarProducto(producto);
        if (exito) {
            JOptionPane.showMessageDialog(ventanaActual, "Producto actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, "No se pudo actualizar el producto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return exito;
    }

    public boolean cambiarEstadoDisponibilidad(int idProducto, boolean disponible, JFrame ventanaActual) {
        boolean exito = productoDAO.actualizarDisponibilidad(idProducto, disponible);
        if (exito) {
            String estadoStr = disponible ? "habilitado" : "dado de baja / deshabilitado";
            JOptionPane.showMessageDialog(ventanaActual, "El producto ha sido " + estadoStr + ".", "Actualización", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, "No se pudo cambiar el estado del producto.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return exito;
    }
}