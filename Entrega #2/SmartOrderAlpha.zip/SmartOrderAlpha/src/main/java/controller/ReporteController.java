package controller;

import dao.PedidoDAO;
import model.Pedido;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class ReporteController {
    private final PedidoDAO pedidoDAO;

    public ReporteController() {
        this.pedidoDAO = new PedidoDAO();
    }

    /**
     * Obtiene todos los pedidos del historial para calcular las métricas del reporte.
     */
    public List<Pedido> obtenerDatosReporte(JFrame ventanaActual) {
        try {
            return pedidoDAO.obtenerHistorialPedidos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al conectar con la base de datos para generar el reporte.", "Error de Reporte", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    /**
     * Calcula el ingreso total acumulado de las ventas registradas.
     */
    public double calcularIngresosTotales(List<Pedido> pedidos) {
        if (pedidos == null) return 0.0;
        double total = 0;
        for (Pedido p : pedidos) {
            total += p.getTotal();
        }
        return total;
    }

    /**
     * Cuenta la cantidad total de comandas procesadas.
     */
    public int contarTotalComandas(List<Pedido> pedidos) {
        if (pedidos == null) return 0;
        return pedidos.size();
    }

    /**
     * Exporta el reporte de ventas y estadísticas a un archivo PDF.
     */
    public void exportarReportePDF(List<Pedido> pedidos, double ingresosTotales, int totalComandas, JFrame ventanaActual) {
        if (pedidos == null || pedidos.isEmpty()) {
            JOptionPane.showMessageDialog(ventanaActual, "No hay datos disponibles para exportar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Reporte como PDF");
        fileChooser.setSelectedFile(new java.io.File("Reporte_Ventas_SmartOrder.pdf"));

        int userSelection = fileChooser.showSaveDialog(ventanaActual);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            java.io.File archivoDestino = fileChooser.getSelectedFile();

            Document documento = new Document();
            try {
                PdfWriter.getInstance(documento, new FileOutputStream(archivoDestino));
                documento.open();

                Font fuenteTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
                Font fuenteSub = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
                Font fuenteNormal = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);

                documento.add(new Paragraph("SmartOrder - Reporte de Ventas y Estadísticas", fuenteTitulo));
                documento.add(new Paragraph("Fecha de generación: " + java.time.LocalDateTime.now().toString(), fuenteNormal));
                documento.add(new Paragraph("------------------------------------------------------------------------------------------------------------------"));
                
                documento.add(new Paragraph("Resumen Financiero:", fuenteSub));
                documento.add(new Paragraph(String.format("• Ingresos Totales: $%.2f", ingresosTotales), fuenteNormal));
                documento.add(new Paragraph("• Total de Comandas Procesadas: " + totalComandas, fuenteNormal));
                documento.add(new Paragraph("\n"));

                documento.add(new Paragraph("Detalle de Transacciones:", fuenteSub));
                documento.add(new Paragraph("\n"));

                PdfPTable tabla = new PdfPTable(5);
                tabla.setWidthPercentage(100);
                
                String[] cabeceras = {"ID Pedido", "Mesa / Tipo", "Total ($)", "Estado", "Fecha y Hora"};
                for (String cabecera : cabeceras) {
                    PdfPCell celda = new PdfPCell(new Paragraph(cabecera, fuenteSub));
                    celda.setHorizontalAlignment(PdfPCell.ALIGN_CENTER);
                    tabla.addCell(celda);
                }

                for (Pedido p : pedidos) {
                    tabla.addCell(new Paragraph(String.valueOf(p.getIdPedido()), fuenteNormal));
                    tabla.addCell(new Paragraph(p.getIdMesa() != null ? "Mesa " + p.getIdMesa() : "Llevar", fuenteNormal));
                    tabla.addCell(new Paragraph(String.format("$%.2f", p.getTotal()), fuenteNormal));
                    tabla.addCell(new Paragraph(String.valueOf(p.getIdEstado()), fuenteNormal));
                    tabla.addCell(new Paragraph(p.getFechaHora() != null ? p.getFechaHora().toString() : "N/D", fuenteNormal));
                }

                documento.add(tabla);
                documento.close();

                JOptionPane.showMessageDialog(ventanaActual, "¡Reporte PDF exportado con éxito en:\n" + archivoDestino.getAbsolutePath(), "Exportación Exitosa", JOptionPane.INFORMATION_MESSAGE);

            } catch (DocumentException | IOException e) {
                JOptionPane.showMessageDialog(ventanaActual, "Error al generar el archivo PDF: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}