package controller;

import dao.UsuarioDAO;
import model.Usuario;
import view.LoginVentana;
import view.MenuPrincipalVentana;

import javax.swing.JOptionPane;

public class LoginController {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    // Método que está llamando LoginVentana.java
    public void procesarLogin(String email, String password, LoginVentana vistaLogin) {
        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(vistaLogin, "Por favor complete todos los campos.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Llama al DAO para validar contra la base de datos
        Usuario usuario = usuarioDAO.validarLogin(email, password);

        if (usuario != null) {
            JOptionPane.showMessageDialog(vistaLogin, "¡Bienvenido " + usuario.getName() + "!", "Acceso Concedido", JOptionPane.INFORMATION_MESSAGE);
            
            // Cierra el login y abre el Dashboard principal
            vistaLogin.dispose();
            new MenuPrincipalVentana(usuario).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(vistaLogin, "Credenciales incorrectas o usuario inactivo.", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
        }
    }
}
