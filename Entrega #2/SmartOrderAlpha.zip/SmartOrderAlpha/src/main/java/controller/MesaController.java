package controller;

import dao.MesaDAO;
import model.Mesa;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.List;

public class MesaController {
    private final MesaDAO mesaDAO = new MesaDAO();

    public List<Mesa> listarMesas(JFrame ventanaActual) {
        try {
            return mesaDAO.obtenerMesas();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, 
                "Error al conectar con la base de datos para cargar las mesas: " + e.getMessage(), 
                "Error DAO", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public void cambiarEstadoMesa(int idMesa, String nuevoEstado, JFrame ventanaActual) {
        boolean exito = mesaDAO.actualizarEstadoMesa(idMesa, nuevoEstado);
        
        if (exito) {
            JOptionPane.showMessageDialog(ventanaActual, 
                "La mesa #" + idMesa + " ha cambiado a estado: " + nuevoEstado, 
                "Actualización Exitosa", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, 
                "No se pudo actualizar el estado de la mesa en el sistema.", 
                "Error de Salón", JOptionPane.ERROR_MESSAGE);
        }
    }
}
