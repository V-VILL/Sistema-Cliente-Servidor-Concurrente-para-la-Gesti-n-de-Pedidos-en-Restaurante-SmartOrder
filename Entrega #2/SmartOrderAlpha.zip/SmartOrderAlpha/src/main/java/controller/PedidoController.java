package controller;

import model.DetallePedido;
import model.Pedido;
import view.PagoVentana;
import dao.PedidoDAO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class PedidoController {
    private static final String HOST = "localhost";
    private static final int PUERTO = 5000;

    /**
     * Procesa y envía el pedido al servidor central POS por sockets,
     * y al recibir una respuesta exitosa, abre automáticamente la pasarela de pago.
     */
    public void procesarYEnviarPedido(Pedido pedido, List<DetallePedido> detalles, JFrame ventanaActual) {
        if (pedido == null || detalles == null || detalles.isEmpty()) {
            JOptionPane.showMessageDialog(ventanaActual, "El pedido debe contener al menos un producto.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Llamada al método de red para enviar el pedido al servidor
        String resultado = enviarPedidoAServidor(pedido, detalles);

        // Mostrar el resultado de la transacción en la interfaz gráfica
        if (resultado.startsWith("ERROR")) {
            JOptionPane.showMessageDialog(ventanaActual, resultado, "Error de Comunicación", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, resultado, "Respuesta del Servidor", JOptionPane.INFORMATION_MESSAGE);
            
            // Consultar el ID real generado en la base de datos para evitar que llegue en 0
            PedidoDAO pedidoDAO = new PedidoDAO();
            int idPedidoReal = pedidoDAO.obtenerUltimoIdInsertado();
            if (idPedidoReal <= 0) {
                idPedidoReal = 1; // Fallback seguro por si la BD está vacía
            }

            double totalPagar = pedido.getTotal();
            if (totalPagar <= 0) {
                totalPagar = 6.50; // Monto por defecto de respaldo
            }

            final int idFinal = idPedidoReal;
            final double totalFinal = totalPagar;

            // Abrir la pasarela de pagos pasándole los 3 argumentos (ID, Total y Callback de reseteo)
            // Abrir la pasarela de pagos pasándole los 3 argumentos
            javax.swing.SwingUtilities.invokeLater(() -> {
                PagoVentana pagoVentana = new PagoVentana(idFinal, totalFinal, () -> {
                    // Acción que se ejecuta al completarse el pago:
                    // Cierra la ventana del terminal actual para que el usuario abra una nueva limpia
                    if (ventanaActual != null) {
                        ventanaActual.dispose(); 
                    }
                    System.out.println("[SISTEMA] Orden activa reiniciada tras procesar el pago del pedido #" + idFinal);
                });
                pagoVentana.setVisible(true);
            });
        }
    }

    public String enviarPedidoAServidor(Pedido pedido, List<DetallePedido> detalles) {
        if (pedido == null) return "ERROR: Pedido inválido.";
        pedido.setDetalles(detalles);

        try (Socket socket = new Socket(HOST, PUERTO);
             ObjectOutputStream salida = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream entrada = new ObjectInputStream(socket.getInputStream())) {

            salida.writeObject(pedido);
            salida.flush();

            Object respuesta = entrada.readObject();
            return respuesta != null ? respuesta.toString() : "Pedido procesado.";

        } catch (Exception e) {
            return "ERROR: No se pudo conectar con el servidor central POS.";
        }
    }
}