package controller;

import dao.PedidoDAO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PagoController {
    private final PedidoDAO pedidoDAO;

    public PagoController() {
        this.pedidoDAO = new PedidoDAO();
    }

    /**
     * Procesa el pago de un pedido y lo marca como completado/pagado en MySQL.
     */
    public boolean procesarPago(int idPedido, double montoTotal, String metodoPago, JFrame ventanaActual) {
        if (idPedido <= 0) {
            JOptionPane.showMessageDialog(ventanaActual, "Seleccione un pedido válido para procesar el pago.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        try {
            // Aquí puedes registrar el pago en tu DAO de pagos o actualizar el estado del pedido a pagado
            boolean exito = pedidoDAO.actualizarEstadoPedido(idPedido, 3); // Estado 3: Pagado / Completado

            if (exito) {
                JOptionPane.showMessageDialog(ventanaActual, 
                    String.format("¡Pago procesado con éxito!\n• Pedido ID: %d\n• Método: %s\n• Total Pagado: $%.2f", idPedido, metodoPago, montoTotal), 
                    "Pago Exitoso", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(ventanaActual, "No se pudo actualizar el estado del pedido en la base de datos.", "Error de Pago", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al conectar con la base de datos para el pago: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}