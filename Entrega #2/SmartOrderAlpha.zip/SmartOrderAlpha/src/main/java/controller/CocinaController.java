package controller;

import concurrency.GestorPedidosConcurrente;
import model.Pedido;
import services.EstacionServiceImpl;
import services.IEstacionService;
import dao.PedidoDAO;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CocinaController {
    private final IEstacionService estacionService;
    private final PedidoDAO pedidoDAO;

    public CocinaController() {
        this.estacionService = new EstacionServiceImpl();
        this.pedidoDAO = new PedidoDAO();
    }

    /**
     * Obtiene únicamente los pedidos activos en cocina (Pendientes y En Preparación).
     * Excluye los pedidos listos o finalizados para que salgan de la cola.
     */
    public List<Pedido> obtenerPedidosActivos(JFrame ventanaActual) {
        try {
            List<Pedido> todos = pedidoDAO.obtenerHistorialPedidos();
            List<Pedido> activos = new ArrayList<>();
            
            if (todos != null) {
                for (Pedido p : todos) {
                    // Estados: 1 = Pendiente/Nuevo, 2 = En Preparación
                    // Al pasar a 3 (Listo), ya no se añade a la lista activa de cocina
                    if (p.getIdEstado() == 1 || p.getIdEstado() == 2) {
                        activos.add(p);
                    }
                }
            }
            return activos;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(ventanaActual, "Error al cargar los pedidos activos de cocina.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public Pedido obtenerSiguientePedidoCocina(JFrame ventanaActual) {
        try {
            // Obtiene el siguiente pedido de la cola concurrente segura para hilos
            return GestorPedidosConcurrente.tomarSiguientePedidoCocina();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            JOptionPane.showMessageDialog(ventanaActual, "Error de concurrencia en la cola de cocina.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public boolean actualizarEstadoPedido(int idPedido, int nuevoEstado, JFrame ventanaActual) {
        boolean exito = estacionService.actualizarEstadoEnCocina(idPedido, nuevoEstado);
        
        if (exito) {
            JOptionPane.showMessageDialog(ventanaActual, "El estado del pedido #" + idPedido + " se actualizó correctamente.", "Actualización Exitosa", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(ventanaActual, "No se pudo actualizar el estado del pedido en la base de datos.", "Error de Cocina", JOptionPane.ERROR_MESSAGE);
        }
        return exito; // Retorna el booleano para validar el flujo en la vista
    }
}