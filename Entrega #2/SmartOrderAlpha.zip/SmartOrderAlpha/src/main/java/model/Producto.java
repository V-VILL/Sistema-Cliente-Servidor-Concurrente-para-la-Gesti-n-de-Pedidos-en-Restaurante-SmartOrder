package model;

import java.io.Serializable;

public class Producto implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idProducto;
    private int idCategoria;
    private String nombre;
    private double precio;
    private boolean disponible;
    private String fechaCreacion;
    private String fechaActualizacion;

    public Producto() {}

    public Producto(int idProducto, int idCategoria, String nombre, double precio, boolean disponible) {
        this.idProducto = idProducto;
        this.idCategoria = idCategoria;
        this.nombre = nombre;
        this.precio = precio;
        this.disponible = disponible;
    }

    // --- Métodos Getters y Setters originales ---
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(String fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }

    // --- Métodos auxiliares para la Vista y la JTable ---
    
    /**
     * Retorna el nombre de la categoría en formato de texto para la tabla.
     */
    public String getCategoria() {
        switch (idCategoria) {
            case 1: return "Combos de Pollo";
            case 2: return "Bucket Familiar";
            case 3: return "Acompañamientos";
            case 4: return "Bebidas";
            default: return "General";
        }
    }

    /**
     * Permite asignar la categoría a partir de un texto (inverso de getCategoria).
     */
    public void setCategoria(String nombreCategoria) {
        if (nombreCategoria == null) {
            this.idCategoria = 5; // General por defecto
            return;
        }
        switch (nombreCategoria.trim().toLowerCase()) {
            case "combos de pollo":
            case "combo": 
                this.idCategoria = 1; 
                break;
            case "bucket familiar":
            case "bucket": 
                this.idCategoria = 2; 
                break;
            case "acompañamientos":
            case "acompañamiento": 
                this.idCategoria = 3; 
                break;
            case "bebidas":
            case "bebida": 
                this.idCategoria = 4; 
                break;
            default: 
                this.idCategoria = 5; // General
                break;
        }
    }

    /**
     * Retorna el estado en formato de texto legible para la tabla.
     */
    public String getEstado() {
        return disponible ? "Disponible" : "Agotado";
    }
}
