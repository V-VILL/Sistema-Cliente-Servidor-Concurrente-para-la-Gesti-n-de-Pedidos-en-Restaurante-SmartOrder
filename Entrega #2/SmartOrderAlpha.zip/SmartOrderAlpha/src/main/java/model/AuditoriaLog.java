package model;

import java.io.Serializable;
import java.util.Date;

public class AuditoriaLog implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idLog;
    private int idUsuario;
    private Integer idPedido;
    private String accion;
    private String detalle;
    private Date timestamp;

    public AuditoriaLog() {}

    public AuditoriaLog(int idLog, int idUsuario, Integer idPedido, String accion, String detalle, Date timestamp) {
        this.idLog = idLog;
        this.idUsuario = idUsuario;
        this.idPedido = idPedido;
        this.accion = accion;
        this.detalle = detalle;
        this.timestamp = timestamp;
    }

    public int getIdLog() { return idLog; }
    public void setIdLog(int idLog) { this.idLog = idLog; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public Integer getIdPedido() { return idPedido; }
    public void setIdPedido(Integer idPedido) { this.idPedido = idPedido; }

    public String getAccion() { return accion; }
    public void setAccion(String accion) { this.accion = accion; }

    public String getDetalle() { return detalle; }
    public void setDetalle(String detalle) { this.detalle = detalle; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
}
