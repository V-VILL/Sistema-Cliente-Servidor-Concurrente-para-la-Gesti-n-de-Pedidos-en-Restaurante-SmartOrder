package model;

import java.io.Serializable;

public class EstadoPedido implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idEstado;
    private String nombreEstado;

    public EstadoPedido() {}

    public EstadoPedido(int idEstado, String nombreEstado) {
        this.idEstado = idEstado;
        this.nombreEstado = nombreEstado;
    }

    public int getIdEstado() { return idEstado; }
    public void setIdEstado(int idEstado) { this.idEstado = idEstado; }

    public String getNombreEstado() { return nombreEstado; }
    public void setNombreEstado(String nombreEstado) { this.nombreEstado = nombreEstado; }

    @Override
    public String toString() {
        return nombreEstado;
    }
}
