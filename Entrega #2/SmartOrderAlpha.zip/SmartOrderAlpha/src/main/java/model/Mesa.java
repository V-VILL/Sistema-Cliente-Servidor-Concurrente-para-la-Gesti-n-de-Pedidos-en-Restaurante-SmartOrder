package model;

import java.io.Serializable;

public class Mesa implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idMesa;
    private String numeroMesa;
    private int capacidad;
    private String estado; // "LIBRE", "OCUPADA", "RESERVADA"

    public Mesa() {}

    public Mesa(int idMesa, String numeroMesa, int capacidad, String estado) {
        this.idMesa = idMesa;
        this.numeroMesa = numeroMesa;
        this.capacidad = capacidad;
        this.estado = estado;
    }

    public int getIdMesa() { return idMesa; }
    public void setIdMesa(int idMesa) { this.idMesa = idMesa; }

    public String getNumeroMesa() { return numeroMesa; }
    public void setNumeroMesa(String numeroMesa) { this.numeroMesa = numeroMesa; }

    public int getCapacidad() { return capacidad; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return numeroMesa + " (" + estado + ")";
    }
}
