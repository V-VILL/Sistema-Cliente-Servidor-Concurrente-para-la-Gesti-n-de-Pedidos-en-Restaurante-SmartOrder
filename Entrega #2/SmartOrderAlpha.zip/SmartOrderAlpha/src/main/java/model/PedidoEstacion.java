package model;

import java.io.Serializable;
import java.util.Date;

public class PedidoEstacion implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idPedidoEstacion;
    private int idPedido;
    private int idEstacion;
    private int idUsuario;
    private Date fechaAsignacion;

    public PedidoEstacion() {}

    public PedidoEstacion(int idPedidoEstacion, int idPedido, int idEstacion, int idUsuario, Date fechaAsignacion) {
        this.idPedidoEstacion = idPedidoEstacion;
        this.idPedido = idPedido;
        this.idEstacion = idEstacion;
        this.idUsuario = idUsuario;
        this.fechaAsignacion = fechaAsignacion;
    }

    public int getIdPedidoEstacion() { return idPedidoEstacion; }
    public void setIdPedidoEstacion(int idPedidoEstacion) { this.idPedidoEstacion = idPedidoEstacion; }

    public int getIdPedido() { return idPedido; }
    public void setIdPedido(int idPedido) { this.idPedido = idPedido; }

    public int getIdEstacion() { return idEstacion; }
    public void setIdEstacion(int idEstacion) { this.idEstacion = idEstacion; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public Date getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(Date fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }
}