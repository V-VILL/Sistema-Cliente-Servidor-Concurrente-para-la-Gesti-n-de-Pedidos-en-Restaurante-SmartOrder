package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Pedido implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idPedido;
    private int idUsuario;
    private Integer idMesa;          // Puede ser null si es para llevar
    private int idEstado;            // 1: Recibido, 2: En preparación, etc.
    private Integer idDescuento;     // Puede ser null si no aplica
    private double total;
    private String tipoPedido;       // 'RESTAURANTE' o 'LLEVAR'
    private String fechaHora;
    
    // Lista de detalles asociada al pedido (productos, cantidades, observaciones)
    private List<DetallePedido> detalles;

    public Pedido() {
        this.detalles = new ArrayList<>();
        this.idEstado = 1; // Por defecto 'Recibido'
        this.tipoPedido = "RESTAURANTE";
    }

    public Pedido(int idUsuario, Integer idMesa, int idEstado, Integer idDescuento, double total, String tipoPedido, List<DetallePedido> detalles) {
        this.idUsuario = idUsuario;
        this.idMesa = idMesa;
        this.idEstado = idEstado;
        this.idDescuento = idDescuento;
        this.total = total;
        this.tipoPedido = tipoPedido;
        this.detalles = detalles != null ? detalles : new ArrayList<>();
    }

    // Getters y Setters
    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(Integer idMesa) {
        this.idMesa = idMesa;
    }

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public Integer getIdDescuento() {
        return idDescuento;
    }

    public void setIdDescuento(Integer idDescuento) {
        this.idDescuento = idDescuento;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetallePedido> detalles) {
        this.detalles = detalles;
    }

    // Método auxiliar para agregar ítems cómodamente desde la vista
    public void agregarDetalle(DetallePedido detalle) {
        this.detalles.add(detalle);
    }
}
