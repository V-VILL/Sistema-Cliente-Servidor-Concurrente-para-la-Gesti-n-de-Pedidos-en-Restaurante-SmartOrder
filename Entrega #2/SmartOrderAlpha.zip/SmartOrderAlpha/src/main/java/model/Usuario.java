package model;

import java.io.Serializable;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idUsuario;
    private int idRol;
    private Integer idEstacion; // Puede ser nulo para cajeros o administradores
    private String nombre;
    private String email;
    private String password;
    private boolean activo;

    public Usuario() {}

    public Usuario(int idUsuario, int idRol, Integer idEstacion, String nombre, String email, String password, boolean activo) {
        this.idUsuario = idUsuario;
        this.idRol = idRol;
        this.idEstacion = idEstacion;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.activo = activo;
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public int getIdRol() { return idRol; }
    public void setIdRol(int idRol) { this.idRol = idRol; }

    public Integer getIdEstacion() { return idEstacion; }
    public void setIdEstacion(Integer idEstacion) { this.idEstacion = idEstacion; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    // Métodos de compatibilidad (inglés/español) para evitar errores con DAOs
    public void setName(String nombre) { this.nombre = nombre; }
    public String getName() { return nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
    
    public void setActive(boolean activo) { this.activo = activo; }
    public boolean isActive() { return activo; }
}
