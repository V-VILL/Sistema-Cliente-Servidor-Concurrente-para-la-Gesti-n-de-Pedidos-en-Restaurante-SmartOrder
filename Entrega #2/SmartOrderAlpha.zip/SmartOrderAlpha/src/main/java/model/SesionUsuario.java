package model;

import java.io.Serializable;
import java.util.Date;

public class SesionUsuario implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idSesion;
    private int idUsuario;
    private Date fechaInicio;
    private Date fechaFin;
    private boolean activa;

    public SesionUsuario() {}

    public SesionUsuario(int idSesion, int idUsuario, Date fechaInicio, Date fechaFin, boolean activa) {
        this.idSesion = idSesion;
        this.idUsuario = idUsuario;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.activa = activa;
    }

    public int getIdSesion() { return idSesion; }
    public void setIdSesion(int idSesion) { this.idSesion = idSesion; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public Date getFechaFin() { return fechaFin; }
    public void setFechaFin(Date fechaFin) { this.fechaFin = fechaFin; }

    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }
}
