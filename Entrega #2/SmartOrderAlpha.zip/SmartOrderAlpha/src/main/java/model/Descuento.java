package model;

import java.io.Serializable;
import java.util.Date;

public class Descuento implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idDescuento;
    private String codigo;
    private double porcentaje;
    private boolean activo;
    private Date fechaInicio;
    private Date fechaFin;

    public Descuento() {}

    public Descuento(int idDescuento, String codigo, double porcentaje, boolean activo, Date fechaInicio, Date fechaFin) {
        this.idDescuento = idDescuento;
        this.codigo = codigo;
        this.porcentaje = porcentaje;
        this.activo = activo;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getIdDescuento() { return idDescuento; }
    public void setIdDescuento(int idDescuento) { this.idDescuento = idDescuento; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public double getPorcentaje() { return porcentaje; }
    public void setPorcentaje(double porcentaje) { this.porcentaje = porcentaje; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public Date getFechaFin() { return fechaFin; }
    public void setFechaFin(Date fechaFin) { this.fechaFin = fechaFin; }
}
