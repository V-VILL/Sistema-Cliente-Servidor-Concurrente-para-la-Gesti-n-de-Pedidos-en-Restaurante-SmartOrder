package model;

import java.io.Serializable;

public class Pago implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idPago;
    private int idPedido;
    private String estadoPago; // "PROCESADO", "PENDIENTE"
    private String metodoPago; // "EFECTIVO", "TARJETA", "SINPE"
    private double monto;

    public Pago() {}

    public Pago(int idPedido, String estadoPago, String metodoPago, double monto) {
        this.idPedido = idPedido;
        this.estadoPago = estadoPago;
        this.metodoPago = metodoPago;
        this.monto = monto;
    }

    public int getIdPago() { return idPago; }
    public void setIdPago(int idPago) { this.idPago = idPago; }

    public int getIdPedido() { return idPedido; }
    public void setIdPedido(int idPedido) { this.idPedido = idPedido; }

    public String getEstadoPago() { return estadoPago; }
    public void setEstadoPago(String estadoPago) { this.estadoPago = estadoPago; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }
}
