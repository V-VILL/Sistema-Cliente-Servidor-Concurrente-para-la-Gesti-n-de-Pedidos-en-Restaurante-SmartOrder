package model;

import java.io.Serializable;

public class MensajeRed implements Serializable {
    private static final long serialVersionUID = 1L;

    private String comando; // Ej: "NUEVO_PEDIDO", "CAMBIAR_ESTADO", "AUTENTICAR"
    private Object contenido;

    public MensajeRed(String comando, Object contenido) {
        this.comando = comando;
        this.contenido = contenido;
    }

    public String getComando() { return comando; }
    public Object getContenido() { return contenido; }
}
