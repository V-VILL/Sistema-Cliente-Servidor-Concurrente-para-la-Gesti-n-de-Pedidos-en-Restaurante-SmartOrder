package model;

import java.io.Serializable;

public class EstacionPreparacion implements Serializable {
    private static final long serialVersionUID = 1L;

    private int idEstacion;
    private String nombreEstacion;

    public EstacionPreparacion() {}

    public EstacionPreparacion(int idEstacion, String nombreEstacion) {
        this.idEstacion = idEstacion;
        this.nombreEstacion = nombreEstacion;
    }

    public int getIdEstacion() { return idEstacion; }
    public void setIdEstacion(int idEstacion) { this.idEstacion = idEstacion; }

    public String getNombreEstacion() { return nombreEstacion; }
    public void setNombreEstacion(String nombreEstacion) { this.nombreEstacion = nombreEstacion; }

    @Override
    public String toString() {
        return nombreEstacion;
    }
}
