package network;

import concurrency.GestorPedidosConcurrente;
import model.Pedido;
import services.IPedidoService;
import services.PedidoServiceImpl;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private final Socket socketCliente;
    private final IPedidoService pedidoService;

    public ClientHandler(Socket socketCliente) {
        this.socketCliente = socketCliente;
        this.pedidoService = new PedidoServiceImpl();
    }

    @Override
    public void run() {
        try (ObjectInputStream entrada = new ObjectInputStream(socketCliente.getInputStream());
             ObjectOutputStream salida = new ObjectOutputStream(socketCliente.getOutputStream())) {

            // Leer el objeto pedido enviado por el cliente (ej. la terminal del cajero)
            Object objetoRecibido = entrada.readObject();

            if (objetoRecibido instanceof Pedido) {
                Pedido pedido = (Pedido) objetoRecibido;
                
                // Procesar mediante el servicio (Guarda en BD y encola concurrentemente)
                boolean registrado = pedidoService.crearPedido(pedido, pedido.getDetalles());

                if (registrado) {
                    salida.writeObject("EXITO: Pedido procesado y enviado a cocina correctamente.");
                } else {
                    salida.writeObject("ERROR: No se pudo registrar el pedido en la base de datos.");
                }
                salida.flush();
            }

        } catch (Exception e) {
            System.err.println("Error en la conexión con el cliente: " + e.getMessage());
        } finally {
            try {
                socketCliente.close();
            } catch (Exception ignored) {}
        }
    }
}
