package network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static final int PUERTO = 5000; // Puerto de escucha del servidor POS
    private static final int HILOS_POOL = 10; // Número máximo de conexiones concurrentes soportadas
    private boolean activo = false;

    public void iniciarServidor() {
        ExecutorService poolHilos = Executors.newFixedThreadPool(HILOS_POOL);
        activo = true;

        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("[SERVIDOR] SmartOrder Server iniciado correctamente en el puerto " + PUERTO);

            while (activo) {
                // Espera la conexión de un cliente (Bloqueante hasta que alguien se conecta)
                Socket socketCliente = serverSocket.accept();
                System.out.println("[SERVIDOR] Nueva terminal conectada desde: " + socketCliente.getInetAddress().getHostAddress());

                // Asigna la atención del cliente a un hilo disponible en el Pool (Concurrencia)
                poolHilos.execute(new ClientHandler(socketCliente));
            }

        } catch (IOException e) {
            System.err.println("[SERVIDOR] Error en el ServerSocket: " + e.getMessage());
        } finally {
            poolHilos.shutdown();
            System.out.println("[SERVIDOR] Servidor detenido.");
        }
    }

    // Método opcional para apagar el servidor de forma segura
    public void detenerServidor() {
        this.activo = false;
    }

    // Método main independiente por si deseas correr el servidor como una aplicación de consola en NetBeans
    public static void main(String[] args) {
        Server servidor = new Server();
        servidor.iniciarServidor();
    }
}
