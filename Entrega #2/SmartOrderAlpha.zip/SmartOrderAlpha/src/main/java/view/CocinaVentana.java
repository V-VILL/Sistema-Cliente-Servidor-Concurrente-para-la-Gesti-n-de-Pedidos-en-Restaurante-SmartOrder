package view;

import controller.CocinaController;
import model.Pedido;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CocinaVentana extends VentanaBase {

    private final CocinaController cocinaController;
    private DefaultTableModel modeloTablaPedidos;
    private JTable tablaPedidos;

    public CocinaVentana() {
        super("SmartOrder - Estación de Preparación y Cocina");
        this.cocinaController = new CocinaController();
        setSize(950, 600);
        setLocationRelativeTo(null);
        initComponents();
        cargarPedidosPendientes();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel Superior (Título y Botón de Refrescar)
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(COLOR_NARANJA);
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("PANEL DE COMANDAS ACTIVAS - COCINA");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);

        JButton btnRefrescar = crearBotonAccion("Actualizar Comandas", COLOR_CELESTE);
        btnRefrescar.addActionListener(e -> cargarPedidosPendientes());

        panelNorte.add(lblTitulo, BorderLayout.WEST);
        panelNorte.add(btnRefrescar, BorderLayout.EAST);
        add(panelNorte, BorderLayout.NORTH);

        // Tabla Central de Pedidos Activos
        String[] columnas = {"ID Pedido", "Mesa", "Tipo", "Total ($)", "Estado", "Fecha / Hora"};
        modeloTablaPedidos = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Tabla de solo lectura
            }
        };

        tablaPedidos = new JTable(modeloTablaPedidos);
        tablaPedidos.setRowHeight(25);
        add(new JScrollPane(tablaPedidos), BorderLayout.CENTER);

        // Panel Inferior (Acciones de Cocina: Marcar como Listo / En Preparación)
        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panelSur.setBackground(Color.WHITE);
        panelSur.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        JButton btnMarcarPreparando = crearBotonAccion("Marcar En Preparación", COLOR_CELESTE);
        btnMarcarPreparando.addActionListener(e -> cambiarEstadoSeleccionado(2)); // Estado 2: En Proceso / Preparando

        JButton btnMarcarListo = crearBotonAccion("Marcar Pedido Listo", new Color(46, 125, 50));
        btnMarcarListo.addActionListener(e -> cambiarEstadoSeleccionado(3)); // Estado 3: Listo para Servir

        panelSur.add(btnMarcarPreparando);
        panelSur.add(btnMarcarListo);
        add(panelSur, BorderLayout.SOUTH);
    }

    /**
     * Carga de forma dinámica los pedidos pendientes o activos desde el controlador.
     */
    public void cargarPedidosPendientes() {
        modeloTablaPedidos.setRowCount(0); // Limpiar tabla antes de recargar
        List<Pedido> listaPedidos = cocinaController.obtenerPedidosActivos(this);

        if (listaPedidos != null && !listaPedidos.isEmpty()) {
            for (Pedido p : listaPedidos) {
                Object[] fila = {
                    p.getIdPedido(),
                    p.getIdMesa() != null ? "Mesa " + p.getIdMesa() : "Llevar",
                    p.getTipoPedido() != null ? p.getTipoPedido() : "MESA",
                    String.format("$%.2f", p.getTotal()),
                    obtenerTextoEstado(p.getIdEstado()),
                    p.getFechaHora() != null ? p.getFechaHora().toString() : "Reciente"
                };
                modeloTablaPedidos.addRow(fila);
            }
        }
    }

    private void cambiarEstadoSeleccionado(int nuevoEstado) {
        int filaSeleccionada = tablaPedidos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione una comanda de la tabla.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idPedido = (int) modeloTablaPedidos.getValueAt(filaSeleccionada, 0);
        boolean actualizado = cocinaController.actualizarEstadoPedido(idPedido, nuevoEstado, this);

        if (actualizado) {
            JOptionPane.showMessageDialog(this, "Estado del pedido #" + idPedido + " actualizado con éxito.", "Cocina", JOptionPane.INFORMATION_MESSAGE);
            cargarPedidosPendientes(); // Refrescar la tabla
        }
    }

    private String obtenerTextoEstado(int idEstado) {
        switch (idEstado) {
            case 1: return "Pendiente / Nuevo";
            case 2: return "En Preparación";
            case 3: return "Listo para Servir";
            default: return "Desconocido";
        }
    }
}
