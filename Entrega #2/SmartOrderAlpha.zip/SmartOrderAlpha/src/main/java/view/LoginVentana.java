package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import controller.*;

public class LoginVentana extends VentanaBase {
    
    // Controlador y componentes declarados a nivel de clase
    private final LoginController loginController;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;

    public LoginVentana() {
        super("SmartOrder - Venta de Pollo (Acceso)");
        this.loginController = new LoginController();
        setSize(860, 520);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        setLayout(new GridLayout(1, 2));

        // Panel Izquierdo
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setBackground(COLOR_NARANJA);
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setBorder(new EmptyBorder(40, 40, 40, 40));

        panelIzquierdo.add(Box.createVerticalGlue());

        JLabel lblBadge = new JLabel("RESTAURANTE DE POLLO");
        lblBadge.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblBadge.setForeground(Color.WHITE);
        lblBadge.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelIzquierdo.add(lblBadge);

        panelIzquierdo.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel lblBrand = new JLabel("SmartOrder");
        lblBrand.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblBrand.setForeground(Color.WHITE);
        lblBrand.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelIzquierdo.add(lblBrand);

        panelIzquierdo.add(Box.createRigidArea(new Dimension(0, 8)));

        JLabel lblSubBrand = new JLabel("Sistema Rápido de Venta & Despacho");
        lblSubBrand.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubBrand.setForeground(new Color(224, 247, 250));
        lblSubBrand.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelIzquierdo.add(lblSubBrand);

        panelIzquierdo.add(Box.createVerticalGlue());
        add(panelIzquierdo);

        // Panel Derecho Formulario
        JPanel panelDerecho = new JPanel(new GridBagLayout());
        panelDerecho.setBackground(Color.WHITE);
        panelDerecho.setBorder(new EmptyBorder(40, 45, 40, 45));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 0, 6, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        gbc.gridy = 0;
        JLabel lblTituloForm = new JLabel("Iniciar Sesión");
        lblTituloForm.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTituloForm.setForeground(COLOR_TEXTO);
        panelDerecho.add(lblTituloForm, gbc);

        gbc.gridy = 1;
        JLabel lblSubForm = new JLabel("Ingrese sus credenciales de usuario");
        lblSubForm.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubForm.setForeground(new Color(100, 116, 139));
        panelDerecho.add(lblSubForm, gbc);

        gbc.gridy = 2;
        panelDerecho.add(Box.createRigidArea(new Dimension(0, 10)), gbc);

        gbc.gridy = 3;
        JLabel lblUser = new JLabel("Correo Electrónico");
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblUser.setForeground(COLOR_TEXTO);
        panelDerecho.add(lblUser, gbc);

        gbc.gridy = 4;
        txtUsuario = new JTextField(); // Usando la variable global de la clase
        txtUsuario.setPreferredSize(new Dimension(260, 36));
        panelDerecho.add(txtUsuario, gbc);

        gbc.gridy = 5;
        JLabel lblPass = new JLabel("Contraseña");
        lblPass.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPass.setForeground(COLOR_TEXTO);
        panelDerecho.add(lblPass, gbc);

        gbc.gridy = 6;
        txtContrasena = new JPasswordField(); // Usando la variable global de la clase
        txtContrasena.setPreferredSize(new Dimension(260, 36));
        panelDerecho.add(txtContrasena, gbc);

        gbc.gridy = 7;
        panelDerecho.add(Box.createRigidArea(new Dimension(0, 15)), gbc);

        gbc.gridy = 8;
        JButton btnLogin = crearBotonAccion("Iniciar Sesión", COLOR_CELESTE);
        btnLogin.setPreferredSize(new Dimension(260, 42));
        
        
        btnLogin.addActionListener(e -> btnIngresarActionPerformed(e));
        
        panelDerecho.add(btnLogin, gbc);

        add(panelDerecho);
    }

    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {
        String email = txtUsuario.getText();
        String password = new String(txtContrasena.getPassword());

        
        loginController.procesarLogin(email, password, this);
    }
}
