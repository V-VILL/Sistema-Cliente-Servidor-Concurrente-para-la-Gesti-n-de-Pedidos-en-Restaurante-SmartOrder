package view;

import controller.AuditoriaController;
import dao.AuditoriaDAO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AuditoriaVentana extends VentanaBase {

    private final AuditoriaController auditoriaController;
    private DefaultTableModel modeloTablaAuditoria;
    private JTable tablaAuditoria;

    public AuditoriaVentana() {
        super("SmartOrder - Auditoría y Registro de Actividad");
        this.auditoriaController = new AuditoriaController();
        setSize(950, 600);
        setLocationRelativeTo(null);
        initComponents();
        cargarDatosAuditoria();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel Superior
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(new Color(51, 65, 85)); // Tono gris pizarra profesional para auditoría
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("BITÁCORA DE AUDITORÍA Y TRAZABILIDAD - MYSQL");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);

        JButton btnRefrescar = crearBotonAccion("Actualizar Bitácora", COLOR_CELESTE);
        btnRefrescar.addActionListener(e -> cargarDatosAuditoria());

        panelNorte.add(lblTitulo, BorderLayout.WEST);
        panelNorte.add(btnRefrescar, BorderLayout.EAST);
        add(panelNorte, BorderLayout.NORTH);

        // Tabla Central
        String[] columnas = {"ID", "Usuario", "Acción Realizada", "Detalle del Suceso", "Fecha y Hora"};
        modeloTablaAuditoria = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaAuditoria = new JTable(modeloTablaAuditoria);
        tablaAuditoria.setRowHeight(25);
        add(new JScrollPane(tablaAuditoria), BorderLayout.CENTER);
    }

    public void cargarDatosAuditoria() {
        modeloTablaAuditoria.setRowCount(0);
        List<AuditoriaDAO.RegistroAuditoria> lista = auditoriaController.obtenerHistorialAuditoria(this);

        if (lista != null && !lista.isEmpty()) {
            for (AuditoriaDAO.RegistroAuditoria reg : lista) {
                Object[] fila = {
                    reg.getIdAuditoria(),
                    reg.getUsuario() != null ? reg.getUsuario() : "Sistema",
                    reg.getAccion(),
                    reg.getDetalle(),
                    reg.getFechaHora()
                };
                modeloTablaAuditoria.addRow(fila);
            }
        } else {
            // Si la tabla de auditoría en MySQL está vacía o aún no se ha creado
            JOptionPane.showMessageDialog(this, "No hay registros de auditoría disponibles o la tabla no está inicializada en la BD.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}