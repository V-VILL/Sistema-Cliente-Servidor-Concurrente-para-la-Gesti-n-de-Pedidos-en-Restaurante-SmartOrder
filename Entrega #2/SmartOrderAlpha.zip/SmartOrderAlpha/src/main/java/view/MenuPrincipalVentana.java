package view;

import model.Usuario;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MenuPrincipalVentana extends VentanaBase {

    private final Usuario usuarioActivo;

    public MenuPrincipalVentana(Usuario usuario) {
        super("SmartOrder - Panel Principal (" + (usuario != null ? usuario.getNombre() : "Usuario") + ")");
        this.usuarioActivo = usuario;
        setSize(850, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Header superior de bienvenida
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(COLOR_CELESTE);
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        String nombreUser = usuarioActivo != null ? usuarioActivo.getNombre() : "Operador";
        JLabel lblBienvenida = new JLabel("Bienvenido a SmartOrder, " + nombreUser);
        lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblBienvenida.setForeground(Color.WHITE);

        JButton btnCerrarSesion = crearBotonAccion("Cerrar Sesión", COLOR_NARANJA);
        btnCerrarSesion.addActionListener(e -> {
            this.dispose();
            new LoginVentana().setVisible(true);
        });

        panelNorte.add(lblBienvenida, BorderLayout.WEST);
        panelNorte.add(btnCerrarSesion, BorderLayout.EAST);
        add(panelNorte, BorderLayout.NORTH);

        // Grid central con los accesos a todas las ventanas del sistema
        JPanel panelGrid = new JPanel(new GridLayout(2, 3, 20, 20));
        panelGrid.setBorder(new EmptyBorder(30, 30, 30, 30));
        panelGrid.setBackground(COLOR_FONDO_SALON);

        JButton btnPedidos = crearBotonAccion("Terminal de Pedidos", COLOR_NARANJA);
        btnPedidos.addActionListener(e -> abrirVentana(new PedidoVentana()));

        JButton btnMesas = crearBotonAccion("Control de Mesas", COLOR_CELESTE);
        btnMesas.addActionListener(e -> abrirVentana(new GestionMesaVentana()));

        JButton btnCocina = crearBotonAccion("Estación de Cocina", COLOR_NARANJA);
        btnCocina.addActionListener(e -> abrirVentana(new CocinaVentana()));

        JButton btnProductos = crearBotonAccion("Gestión del Menú", COLOR_CELESTE);
        btnProductos.addActionListener(e -> abrirVentana(new GestionProductosVentana()));

        JButton btnReportes = crearBotonAccion("Reportes Gerenciales", COLOR_NARANJA);
        btnReportes.addActionListener(e -> abrirVentana(new ReporteVentana()));

        JButton btnAuditoria = crearBotonAccion("Auditoría del Sistema", COLOR_CELESTE);
        btnAuditoria.addActionListener(e -> abrirVentana(new AuditoriaVentana()));

        panelGrid.add(btnPedidos);
        panelGrid.add(btnMesas);
        panelGrid.add(btnCocina);
        panelGrid.add(btnProductos);
        panelGrid.add(btnReportes);
        panelGrid.add(btnAuditoria);

        add(panelGrid, BorderLayout.CENTER);
    }

    private void abrirVentana(JFrame ventana) {
        ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana.setVisible(true);
    }
}
