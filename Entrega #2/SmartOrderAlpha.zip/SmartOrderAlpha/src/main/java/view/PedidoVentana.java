package view;

import controller.PedidoController;
import controller.ProductoController;
import model.DetallePedido;
import model.Pedido;
import model.Producto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoVentana extends VentanaBase {
    
    private final PedidoController pedidoController;
    private final ProductoController productoController;
    
    private List<DetallePedido> detallesActuales;
    private DefaultTableModel modeloTablaCarrito;
    private JTable tablaCarrito;
    private JLabel lblTotalPagar;
    private JTextField txtIdMesa;
    private double totalGlobal = 0.0;

    public PedidoVentana() {
        super("SmartOrder - Terminal de Pedidos de Pollo");
        this.pedidoController = new PedidoController();
        this.productoController = new ProductoController();
        this.detallesActuales = new ArrayList<>();
        
        setSize(1000, 650);
        setLocationRelativeTo(null);
        initComponents();
        cargarCatalogoDinamico();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel Superior de Identificación de Mesa
        JPanel panelNorte = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        panelNorte.setBackground(Color.WHITE);
        panelNorte.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(226, 232, 240)));
        
        panelNorte.add(new JLabel("ID de Mesa Actual:"));
        txtIdMesa = new JTextField("2", 5);
        panelNorte.add(txtIdMesa);
        
        JButton btnRefrescarMenu = crearBotonAccion("Cargar Menú Real", COLOR_CELESTE);
        btnRefrescarMenu.addActionListener(e -> cargarCatalogoDinamico());
        panelNorte.add(btnRefrescarMenu);
        
        add(panelNorte, BorderLayout.NORTH);

        // Panel Central para los Productos (Grid dinámico)
        panelProductosGrid = new JPanel(new GridLayout(2, 2, 15, 15));
        panelProductosGrid.setBorder(new EmptyBorder(20, 20, 20, 20));
        panelProductosGrid.setBackground(COLOR_FONDO_SALON);
        add(new JScrollPane(panelProductosGrid), BorderLayout.CENTER);

        // Panel Derecho (Carrito / Resumen de Orden)
        JPanel panelCarrito = new JPanel(new BorderLayout());
        panelCarrito.setPreferredSize(selectorAnchoCarrito());
        panelCarrito.setBackground(Color.WHITE);
        panelCarrito.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, new Color(226, 232, 240)));

        JLabel lblTituloCarrito = new JLabel(" Resumen de Orden Activa", SwingConstants.LEFT);
        lblTituloCarrito.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTituloCarrito.setForeground(COLOR_TEXTO);
        lblTituloCarrito.setBorder(new EmptyBorder(15, 15, 15, 15));
        panelCarrito.add(lblTituloCarrito, BorderLayout.NORTH);

        String[] columnasCarrito = {"Cant", "Artículo", "Subtotal"};
        modeloTablaCarrito = new DefaultTableModel(columnasCarrito, 0);
        tablaCarrito = new JTable(modeloTablaCarrito);
        panelCarrito.add(new JScrollPane(tablaCarrito), BorderLayout.CENTER);

        JPanel panelInferiorCarrito = new JPanel(new GridLayout(2, 1, 8, 8));
        panelInferiorCarrito.setBackground(Color.WHITE);
        panelInferiorCarrito.setBorder(new EmptyBorder(15, 15, 15, 15));

        lblTotalPagar = new JLabel("TOTAL: $0.00", SwingConstants.RIGHT);
        lblTotalPagar.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotalPagar.setForeground(COLOR_NARANJA);

        JButton btnEnviarSocket = crearBotonAccion("Enviar Pedido a Cocina", COLOR_NARANJA);
        btnEnviarSocket.addActionListener(e -> btnEnviarSocketActionPerformed(e));

        panelInferiorCarrito.add(lblTotalPagar);
        panelInferiorCarrito.add(btnEnviarSocket);
        panelCarrito.add(panelInferiorCarrito, BorderLayout.SOUTH);

        add(panelCarrito, BorderLayout.EAST);
    }

    private Dimension selectorAnchoCarrito() {
        return new Dimension(360, 0);
    }

    private JPanel panelProductosGrid;

    /**
     * Carga los productos reales desde la base de datos utilizando el controlador.
     */
    public void cargarCatalogoDinamico() {
        panelProductosGrid.removeAll();
        List<Producto> productos = productoController.obtenerCatalogoProductos(this);

        if (productos != null && !productos.isEmpty()) {
            for (Producto p : productos) {
                JPanel card = new JPanel(new BorderLayout());
                card.setBackground(Color.WHITE);
                card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
                    new EmptyBorder(15, 15, 15, 15)
                ));

                JLabel lblNombre = new JLabel(p.getNombre());
                lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 13));
                lblNombre.setForeground(COLOR_TEXTO);

                JLabel lblPrecio = new JLabel("$" + p.getPrecio());
                lblPrecio.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblPrecio.setForeground(COLOR_NARANJA);

                JButton btnAdd = crearBotonAccion("Agregar al Pedido", COLOR_CELESTE);
                btnAdd.addActionListener(e -> agregarProductoAlCarrito(p));

                JPanel infoCard = new JPanel(new GridLayout(2, 1));
                infoCard.setBackground(Color.WHITE);
                infoCard.add(lblNombre);
                infoCard.add(lblPrecio);

                card.add(infoCard, BorderLayout.CENTER);
                card.add(btnAdd, BorderLayout.SOUTH);
                panelProductosGrid.add(card);
            }
        }
        panelProductosGrid.revalidate();
        panelProductosGrid.repaint();
    }

    private void agregarProductoAlCarrito(Producto p) {
        DetallePedido detalle = new DetallePedido();
        detalle.setIdProducto(p.getIdProducto());
        detalle.setCantidad(1);
        detalle.setPrecioUnitario(p.getPrecio());
        
        detallesActuales.add(detalle);
        totalGlobal += p.getPrecio();

        modeloTablaCarrito.addRow(new Object[]{1, p.getNombre(), "$" + p.getPrecio()});
        lblTotalPagar.setText("TOTAL: $" + String.format("%.2f", totalGlobal));
    }

    private void btnEnviarSocketActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int idMesa = Integer.parseInt(txtIdMesa.getText().trim());
            
            if (detallesActuales.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe agregar al menos un producto al carrito.", "Aviso", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Pedido pedido = new Pedido();
            pedido.setIdMesa(idMesa);
            pedido.setTotal(totalGlobal);
            
            // Asignar valores obligatorios que faltaban para cumplir con la Base de Datos:
            pedido.setIdUsuario(1);       // ID del usuario/cajero activo por defecto (ej. Admin o Operador 1)
            pedido.setIdEstado(1);        // 1 = Estado Nuevo / Pendiente en cocina
            pedido.setTipoPedido("MESA"); // Tipo de servicio ('MESA', 'LLEVAR', etc.)

            // Delegación real al controlador de pedidos
            pedidoController.procesarYEnviarPedido(pedido, detallesActuales, this);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID de mesa válido.", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }
}