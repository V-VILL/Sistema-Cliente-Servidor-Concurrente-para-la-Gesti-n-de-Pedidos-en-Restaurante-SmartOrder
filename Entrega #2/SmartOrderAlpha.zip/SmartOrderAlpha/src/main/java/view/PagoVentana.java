package view;

import controller.PagoController;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class PagoVentana extends VentanaBase {

    private final PagoController pagoController;
    private final int idPedido;
    private final double totalPagar;
    
    private JComboBox<String> cmbMetodoPago;
    private JTextField txtMontoRecibido;
    private JLabel lblCambio;
    private JPanel panelDinamicoInferior;
    private CardLayout cardLayout;
private Runnable onPagoCompletado; // Callback de reseteo

    // Nuevo constructor que acepta la acción de limpieza
    public PagoVentana(int idPedido, double totalPagar, Runnable onPagoCompletado) {
        super("SmartOrder - Pasarela de Pago Inteligente");
        this.pagoController = new PagoController();
        this.idPedido = idPedido;
        this.totalPagar = totalPagar;
        this.onPagoCompletado = onPagoCompletado;

        setSize(500, 480);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // 1. Panel Superior (Encabezado Ejecutivo)
        JPanel panelNorte = new JPanel(new GridLayout(2, 1));
        panelNorte.setBackground(COLOR_NARANJA);
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("PASARELA DE COBRO - PEDIDO #" + idPedido);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Seleccione el método de pago para procesar la transacción");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSub.setForeground(new Color(255, 243, 224));

        panelNorte.add(lblTitulo);
        panelNorte.add(lblSub);
        add(panelNorte, BorderLayout.NORTH);

        // 2. Panel Central (Formulario)
        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBorder(new EmptyBorder(20, 25, 10, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 1: Total a Pagar
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.4;
        JLabel lblTotalText = new JLabel("Total a Pagar:");
        lblTotalText.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panelCentro.add(lblTotalText, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.6;
        JLabel lblValorTotal = new JLabel(String.format("$%.2f", totalPagar));
        lblValorTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblValorTotal.setForeground(new Color(46, 125, 50));
        panelCentro.add(lblValorTotal, gbc);

        // Fila 2: Método de Pago
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.4;
        JLabel lblMetodo = new JLabel("Método de Pago:");
        lblMetodo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        panelCentro.add(lblMetodo, gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.6;
        String[] metodos = {"Efectivo", "Tarjeta de Crédito / Débito", "SINPE Móvil"};
        cmbMetodoPago = new JComboBox<>(metodos);
        cmbMetodoPago.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panelCentro.add(cmbMetodoPago, gbc);

        // Fila 3: Panel Dinámico según el método de pago (Efectivo vs Tarjeta/Sinpe)
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        cardLayout = new CardLayout();
        panelDinamicoInferior = new JPanel(cardLayout);
        
        // Vista para EFECTIVO (Cálculo de cambio)
        JPanel panelEfectivo = new JPanel(new GridLayout(2, 2, 5, 5));
        panelEfectivo.setBorder(BorderFactory.createTitledBorder(" Detalle de Efectivo "));
        JLabel lblRecibido = new JLabel("Monto Recibido ($):");
        txtMontoRecibido = new JTextField(String.valueOf(totalPagar));
        JLabel lblCambioText = new JLabel("Cambio / Vuelto:");
        lblCambio = new JLabel("$0.00");
        lblCambio.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCambio.setForeground(new Color(46, 125, 50));
        
        panelEfectivo.add(lblRecibido);
        panelEfectivo.add(txtMontoRecibido);
        panelEfectivo.add(lblCambioText);
        panelEfectivo.add(lblCambio);

        // Vista para CAJAS / SINPE / TARJETA (Instrucciones)
        JPanel panelInstrucciones = new JPanel(new BorderLayout());
        panelInstrucciones.setBorder(BorderFactory.createTitledBorder(" Información de Cobro "));
        JTextArea txtInstruccion = new JTextArea(
            "• Para EFECTIVO o SINPE MÓVIL:\n" +
            "  El pedido #" + idPedido + " ha sido registrado.\n" +
            "  Por favor, indique al cliente pasar a CAJAS para completar el cobro."
        );
        txtInstruccion.setEditable(false);
        txtInstruccion.setOpaque(false);
        txtInstruccion.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        txtInstruccion.setForeground(new Color(60, 60, 60));
        panelInstrucciones.add(txtInstruccion, BorderLayout.CENTER);

        panelDinamicoInferior.add(panelEfectivo, "EFECTIVO");
        panelDinamicoInferior.add(panelInstrucciones, "OTROS");
        
        panelCentro.add(panelDinamicoInferior, gbc);
        add(panelCentro, BorderLayout.CENTER);

        // 3. Panel Inferior (Botones de Acción)
        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panelSur.setBorder(new EmptyBorder(0, 20, 15, 20));

        JButton btnCancelar = crearBotonAccion("Cancelar", new Color(100, 116, 139));
        btnCancelar.addActionListener(e -> dispose());

        JButton btnConfirmarPago = crearBotonAccion("Procesar Transacción", new Color(46, 125, 50));
        btnConfirmarPago.addActionListener(e -> manejarConfirmacionPago());

        panelSur.add(btnCancelar);
        panelSur.add(btnConfirmarPago);
        add(panelSur, BorderLayout.SOUTH);

        // Evento de cambio de método de pago en el ComboBox
        cmbMetodoPago.addActionListener(e -> {
            String seleccionado = (String) cmbMetodoPago.getSelectedItem();
            if ("Efectivo".equals(seleccionado)) {
                cardLayout.show(panelDinamicoInferior, "EFECTIVO");
            } else {
                cardLayout.show(panelDinamicoInferior, "OTROS");
            }
        });

        // Evento keyListener para calcular el cambio en tiempo real
        txtMontoRecibido.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calcularCambio();
            }
        });
    }

    private void calcularCambio() {
        try {
            double recibido = Double.parseDouble(txtMontoRecibido.getText().trim());
            double cambio = recibido - totalPagar;
            if (cambio >= 0) {
                lblCambio.setText(String.format("$%.2f", cambio));
                lblCambio.setForeground(new Color(46, 125, 50));
            } else {
                lblCambio.setText("Monto insuficiente");
                lblCambio.setForeground(Color.RED);
            }
        } catch (NumberFormatException e) {
            lblCambio.setText("$0.00");
        }
    }

    private void manejarConfirmacionPago() {
        String metodoSeleccionado = (String) cmbMetodoPago.getSelectedItem();

        if ("Tarjeta de Crédito / Débito".equals(metodoSeleccionado)) {
            boolean exito = pagoController.procesarPago(idPedido, totalPagar, metodoSeleccionado, this);
            if (exito) {
                if (onPagoCompletado != null) {
                    onPagoCompletado.run(); // ¡Aquí se ejecuta el reseteo de la orden activa!
                }
                dispose(); 
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Pedido #" + idPedido + " asignado a modalidad [" + metodoSeleccionado + "].\n" +
                "Diríjase a CAJAS para procesar el cobro e imprimir el comprobante.", 
                "Instrucción de Caja", JOptionPane.INFORMATION_MESSAGE);
            
            if (onPagoCompletado != null) {
                onPagoCompletado.run(); // ¡Resetea la orden activa también aquí!
            }
            dispose();
        }
    }

    private void abrirNuevoPedidoTerminal() {
        // Vuelve a abrir la ventana principal de Terminal de Pedidos para iniciar una nueva comanda
        javax.swing.SwingUtilities.invokeLater(() -> {
            // Instancia o reabre tu ventana de terminal de pedidos según tu proyecto
            // Ejemplo: new view.TerminalPedidosVentana().setVisible(true);
        });
    }
}