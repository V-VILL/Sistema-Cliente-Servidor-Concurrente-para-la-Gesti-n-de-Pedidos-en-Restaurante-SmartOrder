package view;

import javax.swing.*;
import java.awt.*;

public abstract class VentanaBase extends JFrame {
    protected final Color COLOR_NARANJA = new Color(230, 81, 0);      // Naranja Vivo Principal
    protected final Color COLOR_CELESTE = new Color(0, 131, 143);     // Celeste Secundario de Acento
    protected final Color COLOR_OSCURO = new Color(28, 42, 56);       // Azul Pizarra Oscuro
    protected final Color COLOR_FONDO_SALON = new Color(245, 240, 232); // Fondo cálido para mesas
    protected final Color COLOR_TEXTO = new Color(15, 23, 42);

    public VentanaBase(String titulo) {
        setTitle(titulo);
        setSize(980, 620);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(248, 250, 252));
    }

    protected JButton crearBotonAccion(String texto, Color colorFondo) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(colorFondo);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setContentAreaFilled(true);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}