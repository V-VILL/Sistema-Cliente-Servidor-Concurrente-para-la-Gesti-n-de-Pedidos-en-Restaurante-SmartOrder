package view;

import controller.MesaController;
import model.Mesa;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class GestionMesaVentana extends VentanaBase {

    private final MesaController mesaController;
    private JPanel panelMesasGrid;

    public GestionMesaVentana() {
        super("SmartOrder - Control de Mesas y Salón");
        this.mesaController = new MesaController();
        setSize(950, 600);
        setLocationRelativeTo(null);
        initComponents();
        cargarMesasSalon();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelNorte.setBackground(COLOR_CELESTE);
        panelNorte.setBorder(new EmptyBorder(12, 20, 12, 20));
        
        JLabel lblSalón = new JLabel("MAPA DEL SALÓN Y DISPONIBILIDAD DE MESAS");
        lblSalón.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSalón.setForeground(Color.WHITE);
        
        JButton btnActualizar = crearBotonAccion("Refrescar Estado", COLOR_NARANJA);
        btnActualizar.addActionListener(e -> cargarMesasSalon());

        panelNorte.add(lblSalón);
        panelNorte.add(btnActualizar);
        add(panelNorte, BorderLayout.NORTH);

        panelMesasGrid = new JPanel(new GridLayout(2, 3, 20, 20));
        panelMesasGrid.setBorder(new EmptyBorder(25, 25, 25, 25));
        panelMesasGrid.setBackground(COLOR_FONDO_SALON);

        add(new JScrollPane(panelMesasGrid), BorderLayout.CENTER);
    }

    public void cargarMesasSalon() {
        panelMesasGrid.removeAll();
        List<Mesa> listaMesas = mesaController.listarMesas(this);

        if (listaMesas != null && !listaMesas.isEmpty()) {
            for (Mesa mesa : listaMesas) {
                JPanel cardMesa = new JPanel(new BorderLayout());
                cardMesa.setBackground(Color.WHITE);
                cardMesa.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(226, 232, 240), 1),
                    new EmptyBorder(14, 14, 14, 14)
                ));
                
                JLabel lblMesa = new JLabel("Mesa 0" + mesa.getIdMesa(), SwingConstants.CENTER);
                lblMesa.setFont(new Font("Segoe UI", Font.BOLD, 16));
                
                boolean ocupada = "Ocupada".equalsIgnoreCase(mesa.getEstado());
                JLabel lblEstado = new JLabel(ocupada ? "Ocupada" : "Disponible", SwingConstants.CENTER);
                lblEstado.setForeground(ocupada ? COLOR_NARANJA : new Color(46, 125, 50));

                JPanel panelCentroCard = new JPanel(new GridLayout(2, 1));
                panelCentroCard.setBackground(Color.WHITE);
                panelCentroCard.add(lblMesa);
                panelCentroCard.add(lblEstado);

                JButton btnAccion = crearBotonAccion(ocupada ? "Liberar Mesa" : "Ocupar Mesa", ocupada ? COLOR_CELESTE : COLOR_NARANJA);
                final int idMesaActual = mesa.getIdMesa();
                
                btnAccion.addActionListener(e -> {
                    String nuevoEstado = ocupada ? "Libre" : "Ocupada";
                    mesaController.cambiarEstadoMesa(idMesaActual, nuevoEstado, this);
                    cargarMesasSalon();
                });

                cardMesa.add(panelCentroCard, BorderLayout.CENTER);
                cardMesa.add(btnAccion, BorderLayout.SOUTH);
                panelMesasGrid.add(cardMesa);
            }
        }
        panelMesasGrid.revalidate();
        panelMesasGrid.repaint();
    }
}