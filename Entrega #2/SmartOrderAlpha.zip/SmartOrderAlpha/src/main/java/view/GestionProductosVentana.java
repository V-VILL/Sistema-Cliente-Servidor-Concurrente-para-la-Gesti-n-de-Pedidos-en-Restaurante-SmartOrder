package view;

import controller.ProductoController;
import model.Producto;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GestionProductosVentana extends VentanaBase {

    private final ProductoController productoController;
    private DefaultTableModel modeloTabla;
    private JTable tablaProductos;

    public GestionProductosVentana() {
        super("SmartOrder - Gestión del Menú y Productos");
        this.productoController = new ProductoController();
        setSize(950, 600);
        setLocationRelativeTo(null);
        initComponents();
        cargarDatosTabla();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel Superior
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(COLOR_CELESTE);
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("CATÁLOGO DE PRODUCTOS - GESTIÓN DEL MENÚ");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);

        JButton btnRefrescar = crearBotonAccion("Actualizar Lista", COLOR_NARANJA);
        btnRefrescar.addActionListener(e -> cargarDatosTabla());

        panelNorte.add(lblTitulo, BorderLayout.WEST);
        panelNorte.add(btnRefrescar, BorderLayout.EAST);
        add(panelNorte, BorderLayout.NORTH);

        // Tabla Central
        String[] columnas = {"ID", "Nombre", "Categoría", "Precio ($)", "Disponible"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaProductos = new JTable(modeloTabla);
        tablaProductos.setRowHeight(25);
        add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        // Panel Inferior (Botones CRUD)
        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        panelSur.setBackground(Color.WHITE);
        panelSur.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(226, 232, 240)));

        JButton btnAgregar = crearBotonAccion("Nuevo Producto", COLOR_CELESTE);
        btnAgregar.addActionListener(e -> abrirFormularioAgregar());

        JButton btnModificar = crearBotonAccion("Modificar Precio/Nombre", COLOR_NARANJA);
        btnModificar.addActionListener(e -> abrirFormularioModificar());

        JButton btnQuitar = crearBotonAccion("Quitar / Cambiar Disponibilidad", new Color(198, 40, 40));
        btnQuitar.addActionListener(e -> cambiarDisponibilidadSeleccionado());

        panelSur.add(btnAgregar);
        panelSur.add(btnModificar);
        panelSur.add(btnQuitar);
        add(panelSur, BorderLayout.SOUTH);
    }

    public void cargarDatosTabla() {
        modeloTabla.setRowCount(0);
        List<Producto> lista = productoController.obtenerTodosLosProductos(this);

        if (lista != null) {
            for (Producto p : lista) {
                Object[] fila = {
                    p.getIdProducto(),
                    p.getNombre(),
                    p.getCategoria() != null ? p.getCategoria() : "General",
                    String.format("$%.2f", p.getPrecio()),
                    p.isDisponible() ? "Sí (Activo)" : "No (Inactivo)"
                };
                modeloTabla.addRow(fila);
            }
        }
    }

    private void abrirFormularioAgregar() {
        JTextField txtNombre = new JTextField();
        JTextField txtCategoria = new JTextField();
        JTextField txtPrecio = new JTextField();

        Object[] mensaje = {
            "Nombre del Producto:", txtNombre,
            "Categoría:", txtCategoria,
            "Precio ($):", txtPrecio
        };

        int opcion = JOptionPane.showConfirmDialog(this, mensaje, "Registrar Nuevo Producto", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            try {
                Producto nuevo = new Producto();
                nuevo.setNombre(txtNombre.getText().trim());
                nuevo.setCategoria(txtCategoria.getText().trim());
                nuevo.setPrecio(Double.parseDouble(txtPrecio.getText().trim()));
                nuevo.setDisponible(true);

                if (productoController.guardarProducto(nuevo, this)) {
                    cargarDatosTabla();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "El precio debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void abrirFormularioModificar() {
        int fila = tablaProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un producto de la tabla.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modeloTabla.getValueAt(fila, 0);
        String nombreActual = (String) modeloTabla.getValueAt(fila, 1);
        String precioStrActual = ((String) modeloTabla.getValueAt(fila, 3)).replace("$", "").trim();

        JTextField txtNombre = new JTextField(nombreActual);
        JTextField txtPrecio = new JTextField(precioStrActual);

        Object[] mensaje = {
            "Modificar Nombre:", txtNombre,
            "Modificar Precio ($):", txtPrecio
        };

        int opcion = JOptionPane.showConfirmDialog(this, mensaje, "Editar Producto #" + id, JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            try {
                Producto prod = new Producto();
                prod.setIdProducto(id);
                prod.setNombre(txtNombre.getText().trim());
                prod.setPrecio(Double.parseDouble(txtPrecio.getText().trim()));

                if (productoController.actualizarProducto(prod, this)) {
                    cargarDatosTabla();
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Formato de precio incorrecto.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cambiarDisponibilidadSeleccionado() {
        int fila = tablaProductos.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Por favor seleccione un producto de la tabla.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) modeloTabla.getValueAt(fila, 0);
        String estadoActualStr = (String) modeloTabla.getValueAt(fila, 4);
        boolean estadoActual = estadoActualStr.contains("Sí");

        // Alternar disponibilidad (si está activo lo desactiva, y viceversa)
        boolean nuevoEstado = !estadoActual;

        if (productoController.cambiarEstadoDisponibilidad(id, nuevoEstado, this)) {
            cargarDatosTabla();
        }
    }
}