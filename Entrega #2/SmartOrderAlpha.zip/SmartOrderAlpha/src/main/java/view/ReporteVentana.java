package view;

import controller.ReporteController;
import model.Pedido;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReporteVentana extends VentanaBase {

    private final ReporteController reporteController;
    private DefaultTableModel modeloTablaReporte;
    private JTable tablaReporte;
    private JLabel lblIngresosTotales;
    private JLabel lblTotalComandas;

    public ReporteVentana() {
        super("SmartOrder - Reportes y Estadísticas de Ventas");
        this.reporteController = new ReporteController();
        setSize(950, 650);
        setLocationRelativeTo(null);
        initComponents();
        cargarMetricasYReporte();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel Superior (Título y Botones)
        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBackground(COLOR_NARANJA);
        panelNorte.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitulo = new JLabel("REPORTE DE VENTAS Y ESTADÍSTICAS - MYSQL");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBotones.setOpaque(false);

        JButton btnRefrescar = crearBotonAccion("Actualizar", COLOR_CELESTE);
        btnRefrescar.addActionListener(e -> cargarMetricasYReporte());

        JButton btnExportarPDF = crearBotonAccion("Exportar PDF", new Color(46, 125, 50));
        btnExportarPDF.addActionListener(e -> {
            List<Pedido> listaActual = reporteController.obtenerDatosReporte(this);
            double ingresos = reporteController.calcularIngresosTotales(listaActual);
            int comandas = reporteController.contarTotalComandas(listaActual);
            reporteController.exportarReportePDF(listaActual, ingresos, comandas, this);
        });

        panelBotones.add(btnRefrescar);
        panelBotones.add(btnExportarPDF);

        panelNorte.add(lblTitulo, BorderLayout.WEST);
        panelNorte.add(panelBotones, BorderLayout.EAST);

        // Panel de Tarjetas de Resumen (KPIs)
        JPanel panelResumen = new JPanel(new GridLayout(1, 2, 20, 0));
        panelResumen.setBorder(new EmptyBorder(15, 20, 15, 20));
        panelResumen.setBackground(new Color(248, 250, 252));

        lblIngresosTotales = new JLabel("Ingresos Totales: $0.00", JLabel.CENTER);
        lblIngresosTotales.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblIngresosTotales.setBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)));
        lblIngresosTotales.setBackground(Color.WHITE);
        lblIngresosTotales.setOpaque(true);

        lblTotalComandas = new JLabel("Comandas Registradas: 0", JLabel.CENTER);
        lblTotalComandas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalComandas.setBorder(BorderFactory.createLineBorder(new Color(226, 232, 240)));
        lblTotalComandas.setBackground(Color.WHITE);
        lblTotalComandas.setOpaque(true);

        panelResumen.add(lblIngresosTotales);
        panelResumen.add(lblTotalComandas);
        
        JPanel panelNorteContenedor = new JPanel(new BorderLayout());
        panelNorteContenedor.add(panelNorte, BorderLayout.NORTH);
        panelNorteContenedor.add(panelResumen, BorderLayout.CENTER);
        add(panelNorteContenedor, BorderLayout.NORTH);

        // Tabla Central con el detalle histórico de ventas
        String[] columnas = {"ID Pedido", "Mesa / Tipo", "Total ($)", "Estado", "Fecha y Hora"};
        modeloTablaReporte = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaReporte = new JTable(modeloTablaReporte);
        tablaReporte.setRowHeight(25);
        add(new JScrollPane(tablaReporte), BorderLayout.CENTER);
    }

    public void cargarMetricasYReporte() {
        modeloTablaReporte.setRowCount(0);
        List<Pedido> listaPedidos = reporteController.obtenerDatosReporte(this);

        if (listaPedidos != null && !listaPedidos.isEmpty()) {
            double ingresos = reporteController.calcularIngresosTotales(listaPedidos);
            int cantidadComandas = reporteController.contarTotalComandas(listaPedidos);

            lblIngresosTotales.setText(String.format("Ingresos Totales: $%.2f", ingresos));
            lblTotalComandas.setText("Comandas Registradas: " + cantidadComandas);

            for (Pedido p : listaPedidos) {
                Object[] fila = {
                    p.getIdPedido(),
                    p.getIdMesa() != null ? "Mesa " + p.getIdMesa() : "Llevar",
                    String.format("$%.2f", p.getTotal()),
                    obtenerTextoEstado(p.getIdEstado()),
                    p.getFechaHora() != null ? p.getFechaHora().toString() : "N/D"
                };
                modeloTablaReporte.addRow(fila);
            }
        } else {
            lblIngresosTotales.setText("Ingresos Totales: $0.00");
            lblTotalComandas.setText("Comandas Registradas: 0");
            JOptionPane.showMessageDialog(this, "No se encontraron registros de ventas en la base de datos.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private String obtenerTextoEstado(int idEstado) {
        switch (idEstado) {
            case 1: return "Pendiente";
            case 2: return "En Preparación";
            case 3: return "Listo / Completado";
            default: return "Registrado";
        }
    }
}