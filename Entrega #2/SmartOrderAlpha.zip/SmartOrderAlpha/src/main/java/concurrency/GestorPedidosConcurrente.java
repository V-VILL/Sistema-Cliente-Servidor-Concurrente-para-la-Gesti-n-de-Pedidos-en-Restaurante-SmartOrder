package concurrency;

import model.Pedido;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class GestorPedidosConcurrente {
    // Mapa seguro para almacenar pedidos activos en memoria (Clave: idPedido, Valor: Objeto Pedido)
    private static final Map<Integer, Pedido> pedidosActivos = new ConcurrentHashMap<>();
    
    // Cola bloqueante segura para hilos, ideal para la estación de cocina (FIFO)
    private static final BlockingQueue<Pedido> colaCocina = new LinkedBlockingQueue<>();

    // Agregar un nuevo pedido al sistema concurrente
    public static void agregarPedidoActivo(Pedido pedido) {
        if (pedido != null) {
            pedidosActivos.put(pedido.getIdPedido(), pedido);
            try {
                colaCocina.put(pedido); // Inserta el pedido en la cola de cocina de forma segura
                System.out.println("[CONCURRENCIA] Pedido #" + pedido.getIdPedido() + " agregado al gestor y a la cola de cocina.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Error al encolar el pedido para cocina: " + e.getMessage());
            }
        }
    }

    // Obtener y remover el siguiente pedido pendiente para la cocina (Bloquea si la cola está vacía hasta que llegue uno nuevo)
    public static Pedido tomarSiguientePedidoCocina() throws InterruptedException {
        return colaCocina.take();
    }

    // Consultar un pedido activo por su ID
    public static Pedido obtenerPedido(int idPedido) {
        return pedidosActivos.get(idPedido);
    }

    // Remover o finalizar un pedido de los activos
    public static void removerPedidoActivo(int idPedido) {
        pedidosActivos.remove(idPedido);
        System.out.println("[CONCURRENCIA] Pedido #" + idPedido + " finalizado y removido de los activos en memoria.");
    }

    // Obtener la cantidad de pedidos pendientes en la cola de cocina
    public static int obtenerTamanioColaCocina() {
        return colaCocina.size();
    }
}