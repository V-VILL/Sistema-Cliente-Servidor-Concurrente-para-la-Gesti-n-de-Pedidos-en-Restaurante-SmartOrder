package dao;

import model.Mesa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MesaDAO {

    public List<Mesa> obtenerMesas() {
        List<Mesa> lista = new ArrayList<>();
        String sql = "SELECT id_mesa, numero_mesa, capacidad, estado FROM mesas";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Mesa mesa = new Mesa(
                    rs.getInt("id_mesa"),
                    rs.getString("numero_mesa"),
                    rs.getInt("capacidad"),
                    rs.getString("estado")
                );
                lista.add(mesa);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener las mesas: " + e.getMessage());
        }
        return lista;
    }

    public boolean actualizarEstadoMesa(int idMesa, String nuevoEstado) {
        String sql = "UPDATE mesas SET estado = ? WHERE id_mesa = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nuevoEstado);
            stmt.setInt(2, idMesa);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado de la mesa: " + e.getMessage());
            return false;
        }
    }
}