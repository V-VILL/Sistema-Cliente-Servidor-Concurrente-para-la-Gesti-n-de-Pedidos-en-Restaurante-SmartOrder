package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PagoDAO {

    public boolean registrarPago(int idPedido, String metodoPago, double monto) {
        String sql = "INSERT INTO pagos (id_pedido, estado_pago, metodo_pago, monto) VALUES (?, 'PROCESADO', ?, ?)";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idPedido);
            stmt.setString(2, metodoPago);
            stmt.setDouble(3, monto);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar el pago: " + e.getMessage());
            return false;
        }
    }
}
