package dao;

import model.EstacionPreparacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstacionPreparacionDAO {

    public List<EstacionPreparacion> obtenerEstaciones() {
        List<EstacionPreparacion> lista = new ArrayList<>();
        String sql = "SELECT id_estacion, nombre_estacion FROM estaciones_preparacion";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                EstacionPreparacion est = new EstacionPreparacion(
                    rs.getInt("id_estacion"),
                    rs.getString("nombre_estacion")
                );
                lista.add(est);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener las estaciones de preparación: " + e.getMessage());
        }
        return lista;
    }
}
