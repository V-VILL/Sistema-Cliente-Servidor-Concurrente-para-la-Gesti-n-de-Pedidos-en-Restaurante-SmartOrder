package dao;

import model.DetallePedido;
import model.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public boolean registrarPedidoCompleto(Pedido pedido, List<DetallePedido> detalles) {
        String sqlPedido = "INSERT INTO pedidos (id_usuario, id_mesa, id_estado, id_descuento, total, tipo_pedido, fecha_hora) VALUES (?, ?, ?, ?, ?, ?, NOW())";
        String sqlDetalle = "INSERT INTO detalles_pedido (id_pedido, id_producto, cantidad, precio_unitario, observaciones) VALUES (?, ?, ?, ?, ?)";
        
        Connection conn = null;
        try {
            conn = ConexionBD.obtenerConexion();
            conn.setAutoCommit(false); // Iniciar transacción atómica

            
            try (PreparedStatement stmtPedido = conn.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {
                stmtPedido.setInt(1, pedido.getIdUsuario());
                if (pedido.getIdMesa() != null) {
                    stmtPedido.setInt(2, pedido.getIdMesa());
                } else {
                    stmtPedido.setNull(2, java.sql.Types.INTEGER);
                }
                stmtPedido.setInt(3, pedido.getIdEstado());
                if (pedido.getIdDescuento() != null) {
                    stmtPedido.setInt(4, pedido.getIdDescuento());
                } else {
                    stmtPedido.setNull(4, java.sql.Types.INTEGER);
                }
                stmtPedido.setDouble(5, pedido.getTotal());
                stmtPedido.setString(6, pedido.getTipoPedido());
                
                stmtPedido.executeUpdate();

                // Obtener el ID autoincrementable generado para el pedido
                try (ResultSet rsKeys = stmtPedido.getGeneratedKeys()) {
                    if (rsKeys.next()) {
                        pedido.setIdPedido(rsKeys.getInt(1));
                    } else {
                        throw new SQLException("Error al obtener el ID generado del pedido.");
                    }
                }
            }

            
            try (PreparedStatement stmtDetalle = conn.prepareStatement(sqlDetalle)) {
                for (DetallePedido detalle : detalles) {
                    stmtDetalle.setInt(1, pedido.getIdPedido());
                    stmtDetalle.setInt(2, detalle.getIdProducto());
                    stmtDetalle.setInt(3, detalle.getCantidad());
                    stmtDetalle.setDouble(4, detalle.getPrecioUnitario());
                    stmtDetalle.setString(5, detalle.getObservaciones());
                    stmtDetalle.addBatch();
                }
                stmtDetalle.executeBatch();
            }

            conn.commit(); // Confirmar transacción exitosa
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Revertir cambios si ocurre un error
                } catch (SQLException ex) {
                    System.err.println("Error al realizar rollback: " + ex.getMessage());
                }
            }
            System.err.println("Error transaccional al registrar pedido completo: " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {}
            }
        }
    }

    public boolean cambiarEstadoPedido(int idPedido, int nuevoEstado) {
        String sql = "UPDATE pedidos SET id_estado = ? WHERE id_pedido = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, nuevoEstado);
            stmt.setInt(2, idPedido);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado del pedido: " + e.getMessage());
            return false;
        }
    }

    public List<Pedido> obtenerHistorialPedidos() {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT id_pedido, id_usuario, id_mesa, id_estado, id_descuento, total, tipo_pedido, fecha_hora FROM pedidos ORDER BY fecha_hora DESC";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setIdPedido(rs.getInt("id_pedido"));
                pedido.setIdUsuario(rs.getInt("id_usuario"));

                int idMesaVal = rs.getInt("id_mesa");
                if (!rs.wasNull()) {
                    pedido.setIdMesa(idMesaVal);
                }

                pedido.setIdEstado(rs.getInt("id_estado"));

                int idDescuentoVal = rs.getInt("id_descuento");
                if (!rs.wasNull()) {
                    pedido.setIdDescuento(idDescuentoVal);
                }

                pedido.setTotal(rs.getDouble("total"));
                pedido.setTipoPedido(rs.getString("tipo_pedido"));
                
                

                lista.add(pedido);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener el historial de pedidos: " + e.getMessage());
        }
        return lista;
    }
    /**
     * Actualiza el estado de un pedido en la base de datos MySQL.
     */
    public boolean actualizarEstadoPedido(int idPedido, int nuevoEstado) {
        String sql = "UPDATE pedidos SET id_estado = ? WHERE id_pedido = ?";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, nuevoEstado);
            stmt.setInt(2, idPedido);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado del pedido: " + e.getMessage());
            return false;
        }
    }
    public int obtenerUltimoIdInsertado() {
    String sql = "SELECT MAX(id_pedido) FROM pedidos";
    try (Connection conn = ConexionBD.obtenerConexion();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        System.err.println("Error al obtener último ID: " + e.getMessage());
    }
    return 1; // Retorna 1 por defecto si ocurre algún fallo
    }
}
