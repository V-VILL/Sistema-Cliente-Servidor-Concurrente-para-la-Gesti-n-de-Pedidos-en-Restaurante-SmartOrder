package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AuditoriaDAO {

    public static class RegistroAuditoria {
        private int idAuditoria;
        private String usuario;
        private String accion;
        private String detalle;
        private String fechaHora;

        public int getIdAuditoria() { return idAuditoria; }
        public void setIdAuditoria(int idAuditoria) { this.idAuditoria = idAuditoria; }

        public String getUsuario() { return usuario; }
        public void setUsuario(String usuario) { this.usuario = usuario; }

        public String getAccion() { return accion; }
        public void setAccion(String accion) { this.accion = accion; }

        public String getDetalle() { return detalle; }
        public void setDetalle(String detalle) { this.detalle = detalle; }

        public String getFechaHora() { return fechaHora; }
        public void setFechaHora(String fechaHora) { this.fechaHora = fechaHora; }
    }

    /**
     * Registra un evento o log de auditoría en la base de datos MySQL.
     */
    public boolean registrarLog(int idUsuario, Integer idReferencia, String accion, String detalle) {
        String sql = "INSERT INTO auditoria_logs (id_usuario, id_referencia, accion, detalle, fecha_hora) VALUES (?, ?, ?, ?, NOW())";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idUsuario);
            if (idReferencia != null) {
                stmt.setInt(2, idReferencia);
            } else {
                stmt.setNull(2, java.sql.Types.INTEGER);
            }
            stmt.setString(3, accion);
            stmt.setString(4, detalle);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar log de auditoría: " + e.getMessage());
            return false;
        }
    }

    public boolean registrarLog(String usuario, String accion, String detalle) {
        String sql = "INSERT INTO auditoria_logs (usuario, accion, detalle, fecha_hora) VALUES (?, ?, ?, NOW())";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usuario);
            stmt.setString(2, accion);
            stmt.setString(3, detalle);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar log de auditoría por nombre: " + e.getMessage());
            return false;
        }
    }

    /**
     * Obtiene el historial completo de auditoría desde la tabla auditoria_logs.
     */
    public List<RegistroAuditoria> obtenerRegistrosAuditoria() {
        List<RegistroAuditoria> lista = new ArrayList<>();
        // Consultamos incluyendo id_usuario y manejando posibles nulos de forma segura
        String sql = "SELECT id_auditoria, id_usuario, usuario, accion, detalle, fecha_hora FROM auditoria_logs ORDER BY fecha_hora DESC";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                RegistroAuditoria reg = new RegistroAuditoria();
                reg.setIdAuditoria(rs.getInt("id_auditoria"));
                
                String usr = rs.getString("usuario");
                int idUsr = rs.getInt("id_usuario");
                
                if (usr != null && !usr.trim().isEmpty()) {
                    reg.setUsuario(usr);
                } else if (idUsr > 0) {
                    reg.setUsuario("Usuario #" + idUsr);
                } else {
                    reg.setUsuario("Sistema");
                }

                reg.setAccion(rs.getString("accion"));
                reg.setDetalle(rs.getString("detalle"));
                reg.setFechaHora(rs.getString("fecha_hora"));
                
                lista.add(reg);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener registros de auditoría: " + e.getMessage());
        }
        return lista;
    }
}