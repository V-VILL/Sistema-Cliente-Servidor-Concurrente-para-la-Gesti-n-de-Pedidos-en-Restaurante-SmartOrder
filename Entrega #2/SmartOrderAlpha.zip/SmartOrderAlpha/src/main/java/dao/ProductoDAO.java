package dao;

import model.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    // Método para el panel de gestión (devuelve todos, tanto activos como inactivos)
    public List<Producto> obtenerTodosLosProductos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, id_categoria, nombre, precio, disponible, fecha_creacion, fecha_actualizacion FROM productos";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Producto prod = new Producto();
                prod.setIdProducto(rs.getInt("id_producto"));
                prod.setIdCategoria(rs.getInt("id_categoria"));
                prod.setNombre(rs.getString("nombre"));
                prod.setPrecio(rs.getDouble("precio"));
                prod.setDisponible(rs.getBoolean("disponible"));
                prod.setFechaCreacion(rs.getString("fecha_creacion"));
                prod.setFechaActualizacion(rs.getString("fecha_actualizacion"));
                
                lista.add(prod);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todos los productos: " + e.getMessage());
        }
        return lista;
    }

    // Método para la terminal de pedidos (solo muestra los disponibles para la venta)
    public List<Producto> obtenerProductosDisponibles() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, id_categoria, nombre, precio, disponible, fecha_creacion, fecha_actualizacion FROM productos WHERE disponible = true";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Producto prod = new Producto();
                prod.setIdProducto(rs.getInt("id_producto"));
                prod.setIdCategoria(rs.getInt("id_categoria"));
                prod.setNombre(rs.getString("nombre"));
                prod.setPrecio(rs.getDouble("precio"));
                prod.setDisponible(rs.getBoolean("disponible"));
                prod.setFechaCreacion(rs.getString("fecha_creacion"));
                prod.setFechaActualizacion(rs.getString("fecha_actualizacion"));
                
                lista.add(prod);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener productos disponibles: " + e.getMessage());
        }
        return lista;
    }

    public Producto obtenerProductoPorId(int idProducto) {
        String sql = "SELECT id_producto, id_categoria, nombre, precio, disponible, fecha_creacion, fecha_actualizacion FROM productos WHERE id_producto = ?";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, idProducto);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Producto prod = new Producto();
                    prod.setIdProducto(rs.getInt("id_producto"));
                    prod.setIdCategoria(rs.getInt("id_categoria"));
                    prod.setNombre(rs.getString("nombre"));
                    prod.setPrecio(rs.getDouble("precio"));
                    prod.setDisponible(rs.getBoolean("disponible"));
                    prod.setFechaCreacion(rs.getString("fecha_creacion"));
                    prod.setFechaActualizacion(rs.getString("fecha_actualizacion"));
                    return prod;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar el producto por ID: " + e.getMessage());
        }
        return null;
    }

    public boolean registrarProducto(Producto producto) {
        String sql = "INSERT INTO productos (nombre, precio, disponible, fecha_creacion) VALUES (?, ?, ?, NOW())";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, producto.getNombre());
            stmt.setDouble(2, producto.getPrecio());
            stmt.setBoolean(3, producto.isDisponible());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarProducto(Producto producto) {
        String sql = "UPDATE productos SET nombre = ?, precio = ?, fecha_actualizacion = NOW() WHERE id_producto = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, producto.getNombre());
            stmt.setDouble(2, producto.getPrecio());
            stmt.setInt(3, producto.getIdProducto());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarDisponibilidad(int idProducto, boolean disponible) {
        String sql = "UPDATE productos SET disponible = ?, fecha_actualizacion = NOW() WHERE id_producto = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBoolean(1, disponible);
            stmt.setInt(2, idProducto);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar disponibilidad del producto: " + e.getMessage());
            return false;
        }
    }
}
