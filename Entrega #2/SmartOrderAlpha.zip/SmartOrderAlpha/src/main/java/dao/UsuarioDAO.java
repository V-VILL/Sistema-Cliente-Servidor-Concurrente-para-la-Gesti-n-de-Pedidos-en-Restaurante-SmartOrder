package dao;

import model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UsuarioDAO {

    public Usuario validarLogin(String email, String password) {
        String sql = "SELECT id_usuario, id_rol, id_estacion, nombre, email, activo FROM usuarios WHERE email = ? AND password = ? AND activo = true";
        
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            stmt.setString(2, password);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario user = new Usuario();
                    user.setIdUsuario(rs.getInt("id_usuario"));
                    user.setIdRol(rs.getInt("id_rol"));
                    user.setIdEstacion(rs.getObject("id_estacion") != null ? rs.getInt("id_estacion") : null);
                    user.setName(rs.getString("nombre"));
                    user.setEmail(rs.getString("email"));
                    user.setActive(rs.getBoolean("activo"));
                    return user;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al validar el login del usuario: " + e.getMessage());
        }
        return null; // Retorna null si las credenciales fallan
    }
}
