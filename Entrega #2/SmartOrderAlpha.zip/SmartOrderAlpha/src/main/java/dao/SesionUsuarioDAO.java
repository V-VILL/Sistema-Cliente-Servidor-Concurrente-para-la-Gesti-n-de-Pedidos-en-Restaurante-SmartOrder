package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SesionUsuarioDAO {

    public boolean registrarInicioSesion(int idUsuario) {
        String sql = "INSERT INTO sesiones_usuario (id_usuario, fecha_inicio, activa) VALUES (?, NOW(), true)";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUsuario);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar inicio de sesión: " + e.getMessage());
            return false;
        }
    }

    public boolean cerrarSesion(int idUsuario) {
        String sql = "UPDATE sesiones_usuario SET fecha_fin = NOW(), activa = false WHERE id_usuario = ? AND activa = true";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUsuario);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error al cerrar sesión: " + e.getMessage());
            return false;
        }
    }
}
