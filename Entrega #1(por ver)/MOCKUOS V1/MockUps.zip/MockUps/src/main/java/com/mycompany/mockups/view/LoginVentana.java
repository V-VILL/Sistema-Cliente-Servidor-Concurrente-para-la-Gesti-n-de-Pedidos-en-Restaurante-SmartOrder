package com.mycompany.mockups.view;
import javax.swing.*;
import java.awt.*;



/**
 *
 * @author vvill
 */
public class LoginVentana extends VentanaBase {
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JComboBox<String> cbRol;
    private JButton btnIngresar;

    public LoginVentana() {
        super("Iniciar Sesión");
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel("  Correo / Usuario:"));
        txtUsuario = new JTextField();
        add(txtUsuario);

        add(new JLabel("  Contraseña:"));
        txtContrasena = new JPasswordField();
        add(txtContrasena);

        add(new JLabel("  Rol del Sistema:"));
        cbRol = new JComboBox<>(new String[]{"Personal Atención", "Personal Cocina", "Administrador"});
        add(cbRol);

        btnIngresar = new JButton("Ingresar al Sistema");
        add(new JLabel());
        add(btnIngresar);
    }
            
}
