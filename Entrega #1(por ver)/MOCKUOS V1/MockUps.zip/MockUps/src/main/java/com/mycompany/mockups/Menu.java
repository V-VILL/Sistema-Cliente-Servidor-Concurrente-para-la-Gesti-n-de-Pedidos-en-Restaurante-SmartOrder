package com.mycompany.mockups;
import com.mycompany.mockups.view.*;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class Menu extends JFrame {
    public Menu() {
        setTitle("SmartOrder - Panel de Mockups Visuales");
        setSize(350, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(9, 1, 5, 5));

        add(new JLabel(" Seleccione la ventana a visualizar:", JLabel.CENTER));

        JButton btn1 = new JButton("LoginVentana");
        JButton btn2 = new JButton("MenuVentana");
        JButton btn3 = new JButton("PedidoVentana");
        JButton btn4 = new JButton("GestionMesaVentana");
        JButton btn5 = new JButton("CocinaVentana");
        JButton btn6 = new JButton("PagoVentana");
        JButton btn7 = new JButton("GestionProductosVentana");
        JButton btn8 = new JButton("ReporteVentana");

        add(btn1);
        add(btn2);
        add(btn3);
        add(btn4);
        add(btn5);
        add(btn6);
        add(btn7);
        add(btn8);

        // Eventos para abrir cada ventana de forma visual
        btn1.addActionListener(e -> new LoginVentana().setVisible(true));
        btn2.addActionListener(e -> new MenuVentana().setVisible(true));
        btn3.addActionListener(e -> new PedidoVentana().setVisible(true));
        btn4.addActionListener(e -> new GestionMesaVentana().setVisible(true));
        btn5.addActionListener(e -> new CocinaVentana().setVisible(true));
        btn6.addActionListener(e -> new PagoVentana().setVisible(true));
        btn7.addActionListener(e -> new GestionProductosVentana().setVisible(true));
        btn8.addActionListener(e -> new ReporteVentana().setVisible(true));
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }
}
