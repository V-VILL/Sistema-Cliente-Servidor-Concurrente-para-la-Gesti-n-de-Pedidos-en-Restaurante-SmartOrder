package com.mycompany.mockups.view;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class ReporteVentana extends VentanaBase {
    private JTextArea txtAreaReporte;
    private JButton btnGenerarReporte, btnExportarPDF;

    public ReporteVentana() {
        super("Reportes de Ventas y Auditoría del Sistema");
        setLayout(new BorderLayout(10, 10));

        JPanel panelNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelNorte.add(new JLabel("Tipo de Reporte: "));
        panelNorte.add(new JComboBox<>(new String[]{"Ventas Diarias por Rango", "Rendimiento de Cocina", "Logs de Auditoría de Usuarios"}));
        btnGenerarReporte = new JButton("Generar Reporte");
        panelNorte.add(btnGenerarReporte);
        add(panelNorte, BorderLayout.NORTH);

        txtAreaReporte = new JTextArea();
        txtAreaReporte.setText("=== REPORTE GENERADO DEL SISTEMA SMARTORDER ===\n\n" +
                "1. Total de pedidos procesados hoy: 42\n" +
                "2. Ingresos brutos acumulados: $580.00 USD\n" +
                "3. Plato más vendido: Pizza Pepperoni Familiar\n" +
                "4. Estado de Conexión de Sockets: Estable (Puerto 5000)\n");
        txtAreaReporte.setEditable(false);
        add(new JScrollPane(txtAreaReporte), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnExportarPDF = new JButton("Exportar / Guardar Reporte");
        panelSur.add(btnExportarPDF);
        add(panelSur, BorderLayout.SOUTH);
    }
}
