package com.mycompany.mockups.view;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class PagoVentana extends VentanaBase {
    private JTextField txtDescuento;
    private JComboBox<String> cbMetodoPago;
    private JLabel lblTotalPagar;
    private JButton btnConfirmarPago;

    public PagoVentana() {
        super("Caja y Procesamiento de Pagos");
        setLayout(new GridLayout(5, 2, 10, 10));

        add(new JLabel("  Total del Pedido:"));
        lblTotalPagar = new JLabel("$23.50 USD");
        lblTotalPagar.setFont(new Font("Arial", Font.BOLD, 12));
        add(lblTotalPagar);

        add(new JLabel("  Código de Descuento:"));
        txtDescuento = new JTextField();
        add(txtDescuento);

        add(new JLabel("  Método de Pago:"));
        cbMetodoPago = new JComboBox<>(new String[]{"Efectivo", "Tarjeta de Crédito / Débito", "SINPE Móvil"});
        add(cbMetodoPago);

        add(new JLabel());
        add(new JButton("Aplicar Descuento"));

        btnConfirmarPago = new JButton("Confirmar Pago y Registrar");
        btnConfirmarPago.setBackground(new Color(39, 174, 65));
        btnConfirmarPago.setForeground(Color.WHITE);
        add(new JLabel());
        add(btnConfirmarPago);
    }
}
