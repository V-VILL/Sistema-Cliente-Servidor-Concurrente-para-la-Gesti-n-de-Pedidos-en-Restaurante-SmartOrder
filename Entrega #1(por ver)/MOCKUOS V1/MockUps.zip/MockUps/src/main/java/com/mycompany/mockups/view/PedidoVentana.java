package com.mycompany.mockups.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class PedidoVentana extends VentanaBase {
    private JTable tablaDetalle;
    private DefaultTableModel modeloTabla;
    private JLabel lblTotal;
    private JButton btnEnviarSockets, btnGestionMesas;

    public PedidoVentana() {
        super("Gestión y Detalle de Pedido");
        setLayout(new BorderLayout(10, 10));

        modeloTabla = new DefaultTableModel(new String[]{"Producto", "Cantidad", "Precio Unitario", "Subtotal"}, 0);
        modeloTabla.addRow(new Object[]{"Pizza Pepperoni Familiar", 1, "$14.50", "$14.50"});
        modeloTabla.addRow(new Object[]{"Coca Cola 600ml", 3, "$3.00", "$9.00"});
        tablaDetalle = new JTable(modeloTabla);
        add(new JScrollPane(tablaDetalle), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new BorderLayout());
        lblTotal = new JLabel("   Total Acumulado: $23.50   ");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 14));
        panelSur.add(lblTotal, BorderLayout.WEST);

        JPanel panelBotones = new JPanel(new FlowLayout());
        btnGestionMesas = new JButton("Ver Estado de Mesas");
        btnEnviarSockets = new JButton("Enviar Pedido a Cocina (Sockets)");
        btnEnviarSockets.setBackground(new Color(46, 204, 113));
        btnEnviarSockets.setForeground(Color.WHITE);

        panelBotones.add(btnGestionMesas);
        panelBotones.add(btnEnviarSockets);
        panelSur.add(panelBotones, BorderLayout.EAST);

        add(panelSur, BorderLayout.SOUTH);
    }
}
