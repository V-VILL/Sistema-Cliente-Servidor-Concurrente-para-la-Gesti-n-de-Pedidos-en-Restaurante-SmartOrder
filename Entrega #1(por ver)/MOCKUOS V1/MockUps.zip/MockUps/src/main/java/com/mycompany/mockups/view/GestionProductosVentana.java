package com.mycompany.mockups.view;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class GestionProductosVentana extends VentanaBase {
    private JTable tablaProductos;
    private DefaultTableModel modeloProductos;
    private JButton btnCrear, btnActualizar, btnEliminar, btnVerReportes;

    public GestionProductosVentana() {
        super("Administración de Productos y Menú");
        setLayout(new BorderLayout(10, 10));

        JLabel lblAdmin = new JLabel(" Panel de Control Administrativo (CRUD de Productos)", JLabel.LEFT);
        lblAdmin.setFont(new Font("Arial", Font.BOLD, 12));
        add(lblAdmin, BorderLayout.NORTH);

        modeloProductos = new DefaultTableModel(new String[]{"ID", "Nombre Producto", "Categoría", "Precio ($)", "Disponible"}, 0);
        modeloProductos.addRow(new Object[]{"1", "Pizza Pepperoni Familiar", "Pizzas", "14.50", "Sí"});
        modeloProductos.addRow(new Object[]{"2", "Hamburguesa Doble Queso", "Hamburguesas", "9.00", "Sí"});
        
        tablaProductos = new JTable(modeloProductos);
        add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout());
        btnCrear = new JButton("Nuevo Producto");
        btnActualizar = new JButton("Modificar Producto");
        btnEliminar = new JButton("Dar de Baja");
        btnVerReportes = new JButton("Ver Auditoría / Reportes");

        panelSur.add(btnCrear);
        panelSur.add(btnActualizar);
        panelSur.add(btnEliminar);
        panelSur.add(btnVerReportes);
        add(panelSur, BorderLayout.SOUTH);
    }
}
