package com.mycompany.mockups.view;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class GestionMesaVentana extends VentanaBase {
    private JTable tablaMesas;
    private JButton btnLiberarMesa, btnActualizarEstado;

    public GestionMesaVentana() {
        super("Gestión y Sincronización de Mesas");
        setLayout(new BorderLayout(10, 10));

        String[] columnas = {"ID Mesa", "Número de Mesa", "Estado Actual", "Capacidad"};
        Object[][] datos = {
            {"1", "Mesa 1", "Ocupada (Pedido Activo)", "4 Personas"},
            {"2", "Mesa 2", "Disponible", "2 Personas"},
            {"3", "Mesa 3", "Reservada", "6 Personas"},
            {"4", "Mesa VIP 1", "Ocupada (En Espera de Pago)", "8 Personas"}
        };
        tablaMesas = new JTable(datos, columnas);
        add(new JScrollPane(tablaMesas), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout());
        btnLiberarMesa = new JButton("Liberar Mesa Seleccionada");
        btnActualizarEstado = new JButton("Actualizar Estados");
        
        panelSur.add(btnLiberarMesa);
        panelSur.add(btnActualizarEstado);
        add(panelSur, BorderLayout.SOUTH);
    }
}
