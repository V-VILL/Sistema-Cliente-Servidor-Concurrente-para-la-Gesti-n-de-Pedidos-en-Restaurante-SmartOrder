package com.mycompany.mockups.view;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class MenuVentana extends VentanaBase {
    private JList<String> listaProductos;
    private JButton btnIrAlPedido;

    public MenuVentana() {
        super("Catálogo del Menú");
        setLayout(new BorderLayout(10, 10));

        JPanel panelNorte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelNorte.add(new JLabel("Categoría: "));
        panelNorte.add(new JComboBox<>(new String[]{"Todos", "Pizzas", "Hamburguesas", "Bebidas", "Postres"}));
        panelNorte.add(new JButton("Filtrar"));
        add(panelNorte, BorderLayout.NORTH);

        String[] productos = {
            "Pizza Pepperoni Familiar - $14.50 (Disponible)",
            "Hamburguesa Doble Queso - $9.00 (Disponible)",
            "Coca Cola 600ml - $2.50 (Disponible)",
            "Helado de Gelato Artesanal - $4.00 (Disponible)"
        };
        listaProductos = new JList<>(productos);
        add(new JScrollPane(listaProductos), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnIrAlPedido = new JButton("Ir a Formetar Pedido >>");
        panelSur.add(btnIrAlPedido);
        add(panelSur, BorderLayout.SOUTH);
    }
}
