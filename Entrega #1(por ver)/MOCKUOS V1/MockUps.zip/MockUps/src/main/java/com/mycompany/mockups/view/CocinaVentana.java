package com.mycompany.mockups.view;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 *
 * @author vvill
 */
public class CocinaVentana extends VentanaBase {
    private JTable tablaCocina;
    private DefaultTableModel modeloCocina;
    private JButton btnMarcarPreparacion, btnMarcarListo;

    public CocinaVentana() {
        super("Monitor de Estación de Cocina");
        setLayout(new BorderLayout(10, 10));

        JLabel lblInfo = new JLabel(" Cola Concurrente de Pedidos Entrantes", JLabel.LEFT);
        lblInfo.setFont(new Font("Arial", Font.BOLD, 12));
        add(lblInfo, BorderLayout.NORTH);

        modeloCocina = new DefaultTableModel(new String[]{"ID Pedido", "Mesa", "Detalle de Platillos", "Estado"}, 0);
        modeloCocina.addRow(new Object[]{"101", "Mesa 1", "1x Pizza Pepperoni Familiar, 3x Coca Cola", "Pendiente"});
        modeloCocina.addRow(new Object[]{"102", "Mesa VIP 1", "2x Hamburguesa Doble Queso", "En Preparación"});
        
        tablaCocina = new JTable(modeloCocina);
        add(new JScrollPane(tablaCocina), BorderLayout.CENTER);

        JPanel panelSur = new JPanel(new FlowLayout());
        btnMarcarPreparacion = new JButton("Marcar: En Preparación");
        btnMarcarListo = new JButton("Marcar: ¡Listo para Servir!");
        btnMarcarListo.setBackground(new Color(52, 152, 219));
        btnMarcarListo.setForeground(Color.WHITE);

        panelSur.add(btnMarcarPreparacion);
        panelSur.add(btnMarcarListo);
        add(panelSur, BorderLayout.SOUTH);
    }
}
