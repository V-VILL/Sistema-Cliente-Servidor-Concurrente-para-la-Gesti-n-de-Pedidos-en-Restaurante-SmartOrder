package com.mycompany.mockups.view;
import javax.swing.*;

import javax.swing.JFrame;

/**
 *
 * @author vvill
 */
public abstract class VentanaBase extends JFrame {
    protected String titulo;
    protected boolean estaConectado;

    public VentanaBase(String titulo) {
        this.titulo = titulo;
        setTitle("SmartOrder - " + titulo);
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public void mostrarError(String msj) {
        JOptionPane.showMessageDialog(this, msj, "Error del Sistema", JOptionPane.ERROR_MESSAGE);
    }

    public void cambiarEstadoRed(boolean conectado) {
        this.estaConectado = conectado;
        // Lógica para mostrar indicador de conexión con el servidor de sockets
    }
}
